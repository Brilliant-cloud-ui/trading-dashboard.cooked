import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime, timedelta
import time
import random
import base64
from PIL import Image
import io
import os

# Configuration
st.set_page_config(
    page_title="JustTry Trading Bot - Login",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Session state initialization
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'login_attempts' not in st.session_state:
    st.session_state.login_attempts = 0
if 'show_animation' not in st.session_state:
    st.session_state.show_animation = True
if 'animation_complete' not in st.session_state:
    st.session_state.animation_complete = False
if 'dark_theme' not in st.session_state:
    st.session_state.dark_theme = True
if 'language' not in st.session_state:
    st.session_state.language = "English"
if 'lot_size' not in st.session_state:
    st.session_state.lot_size = "0.01"
if 'risk_reward' not in st.session_state:
    st.session_state.risk_reward = "1:2"
if 'ai_assisted' not in st.session_state:
    st.session_state.ai_assisted = True
if 'execution_alerts' not in st.session_state:
    st.session_state.execution_alerts = True
if 'disconnect_warnings' not in st.session_state:
    st.session_state.disconnect_warnings = True
if 'mt5_connected' not in st.session_state:
    st.session_state.mt5_connected = False
if 'pulse_start_time' not in st.session_state:
    st.session_state.pulse_start_time = datetime.now() - timedelta(hours=3, minutes=5)
if 'show_signup' not in st.session_state:
    st.session_state.show_signup = False
if 'users' not in st.session_state:
    # Initialize with a default admin account
    st.session_state.users = {
        'admin': {
            'password': 'password',
            'email': 'admin@example.com',
            'created_at': datetime.now()
        }
    }

# Set page background with dark blue gradient and remove header
page_bg = """
<style>
    /* Remove the default Streamlit header/toolbar */
    header {
        visibility: hidden;
    }
    
    /* Move the main content up to fill the space of the removed header */
    .main .block-container {
        padding-top: 1rem;
        margin-top: 0rem;
    }
    
    .stApp {
        background: linear-gradient(135deg, #0a1626 0%, #0d1e33 100%);
        color: white;
        font-family: 'Roboto', sans-serif;
    }
</style>
"""
st.markdown(page_bg, unsafe_allow_html=True)

# Custom CSS with animations
st.markdown("""
<style>
    /* Animation for the loading bar */
    @keyframes loadingAnimation {
        0% {
            width: 0%;
            background: linear-gradient(90deg, #00c7b7, #4fc3f7);
        }
        100% {
            width: 100%;
            background: linear-gradient(90deg, #00c7b7, #4fc3f7);
        }
    }
    
    /* Loading bar styling */
    .loading-bar {
        height: 4px;
        border-radius: 2px;
        margin: 20px 0;
        animation: loadingAnimation 1.5s ease-out forwards;
    }
    
    /* Animation for the glowing effect */
    @keyframes glowing {
        0% { box-shadow: 0 0 5px #00c7b7; }
        50% { box-shadow: 0 0 20px #00c7b7, 0 0 30px #4fc3f7; }
        100% { box-shadow: 0 0 5px #00c7b7; }
    }
    
    /* Glow effect for buttons */
    .glow-button {
        background: linear-gradient(45deg, #00c7b7, #4fc3f7);
        color: white;
        border: none;
        border-radius: 4px;
        padding: 10px 20px;
        cursor: pointer;
        animation: glowing 2s infinite;
        transition: all 0.3s ease;
    }
    
    .glow-button:hover {
        transform: scale(1.05);
        animation: glowing 1s infinite;
    }
    
    /* Input field styling */
    .custom-input {
        background-color: rgba(14, 25, 44, 0.7);
        border: 1px solid #2c3857;
        border-radius: 4px;
        color: white;
        padding: 10px 15px;
        margin-bottom: 15px;
        width: 100%;
        transition: all 0.3s ease;
    }
    
    .custom-input:focus {
        border-color: #00c7b7;
        box-shadow: 0 0 8px rgba(0, 199, 183, 0.5);
    }
    
    /* Make input field labels more visible */
    label {
        color: white !important;
        font-weight: 500 !important;
        font-size: 1rem !important;
    }
    
    /* Better styling for text inputs */
    .stTextInput > div > div {
        color: white !important;
        background-color: rgba(10, 22, 38, 0.5) !important;
        border: 1px solid rgba(0, 199, 183, 0.3) !important;
    }
    
    .stTextInput > div > div:focus-within {
        border-color: #00c7b7 !important;
        box-shadow: 0 0 0 1px #00c7b7 !important;
    }
    
    /* Style for password fields */
    div[data-baseweb="input"] input[type="password"] {
        color: white !important;
    }
    
    /* Fancy login container */
    .login-container {
        background-color: rgba(10, 22, 38, 0.8);
        backdrop-filter: blur(10px);
        border-radius: 10px;
        padding: 30px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.1);
        max-width: 400px;
        margin: 0 auto;
    }
    
    /* Logo styling */
    .logo {
        max-width: 150px;
        margin: 0 auto 20px auto;
        display: block;
    }
    
    /* Fade in animation */
    @keyframes fadeIn {
        0% { opacity: 0; transform: translateY(20px); }
        100% { opacity: 1; transform: translateY(0); }
    }
    
    .fade-in {
        animation: fadeIn 1s ease forwards;
    }
    
    .fade-in-delay-1 {
        opacity: 0;
        animation: fadeIn 1s ease forwards 0.5s;
    }
    
    .fade-in-delay-2 {
        opacity: 0;
        animation: fadeIn 1s ease forwards 1s;
    }
    
    .fade-in-delay-3 {
        opacity: 0;
        animation: fadeIn 1s ease forwards 1.5s;
    }
    
    /* Price chart animation */
    @keyframes chartAnimation {
        0% { transform: scaleX(0); transform-origin: left; }
        100% { transform: scaleX(1); transform-origin: left; }
    }
    
    .animate-chart {
        animation: chartAnimation 2s ease forwards;
    }
    
    /* Floating animation for AI bot */
    @keyframes floating {
        0% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0); }
    }
    
    .floating-animation {
        animation: floating 4s ease-in-out infinite;
    }
    
    /* Chart glow effect */
    .chart-glow {
        filter: drop-shadow(0 0 8px rgba(0, 199, 183, 0.7));
    }
    
    /* Particles floating in background */
    .particle {
        position: absolute;
        background-color: rgba(0, 199, 183, 0.5);
        border-radius: 50%;
        animation: float-particle 15s infinite linear;
    }
    
    @keyframes float-particle {
        0% {
            transform: translateY(0) translateX(0);
            opacity: 0;
        }
        10% {
            opacity: 1;
        }
        90% {
            opacity: 1;
        }
        100% {
            transform: translateY(-100vh) translateX(20px);
            opacity: 0;
        }
    }
    
    /* Custom styles for various streamlit elements */
    div.stButton > button {
        background: linear-gradient(45deg, #00c7b7, #4fc3f7);
        color: white;
        border: none;
        padding: 10px 15px;
        font-weight: bold;
        border-radius: 5px;
        transition: all 0.3s ease;
        width: 100%;
    }
    
    div.stButton > button:hover {
        transform: scale(1.05);
        box-shadow: 0 0 15px rgba(0, 199, 183, 0.7);
    }
    
    /* Hide hamburger menu and footer */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    
    /* Robot image styling */
    .robot-container {
        position: relative;
        width: 100%;
        height: 300px;
        margin-bottom: 20px;
        overflow: hidden;
    }
    
    .robot-image {
        position: absolute;
        right: -50px;
        bottom: 0;
        width: 250px;
        z-index: 1;
        animation: floating 4s ease-in-out infinite;
    }
    
    .chart-line {
        position: absolute;
        left: 0;
        top: 50%;
        width: 100%;
        height: 3px;
        background: linear-gradient(90deg, transparent, #00c7b7, #4fc3f7, transparent);
        z-index: 0;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 0.3; height: 2px; }
        50% { opacity: 1; height: 3px; }
        100% { opacity: 0.3; height: 2px; }
    }
    
    /* Logo glow */
    .logo-glow {
        filter: drop-shadow(0 0 8px rgba(0, 199, 183, 0.7));
    }
    
    /* Add glowing dots in the background */
    .glowing-dots {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        z-index: -1;
    }
    
    .dot {
        position: absolute;
        background: radial-gradient(circle, rgba(0, 199, 183, 0.8) 0%, rgba(0, 199, 183, 0) 70%);
        border-radius: 50%;
        opacity: 0.2;
    }
    
    /* Tab styling for login/signup */
    .custom-tabs {
        display: flex;
        margin-bottom: 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .tab {
        padding: 10px 15px;
        cursor: pointer;
        color: #888;
        font-weight: 500;
        transition: all 0.3s ease;
        text-align: center;
        flex: 1;
    }
    
    .tab.active {
        color: #00c7b7;
        border-bottom: 2px solid #00c7b7;
    }
    
    .tab:hover:not(.active) {
        color: white;
    }
    
    /* Password strength indicator */
    .password-strength {
        height: 4px;
        margin-top: 5px;
        border-radius: 2px;
        background: #444;
        overflow: hidden;
    }
    
    .strength-level {
        height: 100%;
        width: 0%;
        transition: width 0.3s ease;
    }
    
    .weak { width: 33%; background: #ff5757; }
    .medium { width: 66%; background: #ffb300; }
    .strong { width: 100%; background: #00c7b7; }
    
    /* Terms checkbox styling */
    .checkbox-container {
        display: flex;
        align-items: center;
        margin: 15px 0;
    }
    
    .terms-text {
        color: #aaa;
        font-size: 0.8em;
        margin-left: 5px;
    }
    
    .terms-link {
        color: #00c7b7;
        text-decoration: none;
    }
    
    .terms-link:hover {
        text-decoration: underline;
    }
</style>
"""
, unsafe_allow_html=True)

# Add animated background dots
st.markdown("""
<div class="glowing-dots">
    <div class="dot" style="top: 10%; left: 20%; width: 6px; height: 6px; animation: pulse 4s infinite;"></div>
    <div class="dot" style="top: 20%; left: 40%; width: 8px; height: 8px; animation: pulse 5s infinite 1s;"></div>
    <div class="dot" style="top: 15%; left: 60%; width: 5px; height: 5px; animation: pulse 3.5s infinite 0.5s;"></div>
    <div class="dot" style="top: 30%; left: 80%; width: 7px; height: 7px; animation: pulse 4.5s infinite 0.7s;"></div>
    <div class="dot" style="top: 40%; left: 25%; width: 9px; height: 9px; animation: pulse 5.5s infinite 1.2s;"></div>
    <div class="dot" style="top: 70%; left: 35%; width: 6px; height: 6px; animation: pulse 4s infinite 0.3s;"></div>
    <div class="dot" style="top: 60%; left: 65%; width: 8px; height: 8px; animation: pulse 4.8s infinite 0.8s;"></div>
    <div class="dot" style="top: 80%; left: 75%; width: 7px; height: 7px; animation: pulse 5s infinite 1.5s;"></div>
    <div class="dot" style="top: 85%; left: 15%; width: 5px; height: 5px; animation: pulse 3.8s infinite 1.1s;"></div>
    <div class="dot" style="top: 90%; left: 45%; width: 6px; height: 6px; animation: pulse 4.2s infinite 0.6s;"></div>
</div>
""", unsafe_allow_html=True)

# Function to generate animated candle chart data
def generate_chart_data():
    # Generate date range
    num_days = 60
    dates = pd.date_range(start='2024-01-01', periods=num_days)
    
    # Generate realistic looking OHLC data
    base_price = 100
    momentum = 0
    volatility = 2.0
    
    opens = []
    highs = []
    lows = []
    closes = []
    volumes = []
    
    # Generate an initial price
    current_price = base_price
    
    for i in range(num_days):
        # Add some randomness but maintain a trend
        random_factor = np.random.normal(0, 1)
        momentum = momentum * 0.8 + random_factor * 0.2
        
        # Add a general uptrend with some noise
        if i < num_days / 2:
            trend = i / (num_days / 2) * 30  # Uptrend for first half
        else:
            trend = 30 - (i - num_days / 2) / (num_days / 2) * 15  # Slight downtrend for second half
        
        # Generate price
        open_price = current_price
        close_change = momentum + np.random.normal(0, volatility)
        close_price = max(open_price + close_change, open_price * 0.9)  # Ensure price doesn't drop too much
        
        # Calculate high and low with realistic volatility
        price_range = max(abs(close_price - open_price) * 1.5, volatility)
        high_price = max(open_price, close_price) + abs(np.random.normal(0, price_range * 0.5))
        low_price = min(open_price, close_price) - abs(np.random.normal(0, price_range * 0.5))
        
        # Generate volume (higher on bigger price moves)
        volume = abs(close_price - open_price) * np.random.uniform(50, 150)
        
        # Add trend component
        open_price += trend
        close_price += trend
        high_price += trend
        low_price += trend
        
        # Store values
        opens.append(open_price)
        highs.append(high_price)
        lows.append(low_price)
        closes.append(close_price)
        volumes.append(volume)
        
        # Set up for next day
        current_price = close_price
    
    # Create the candlestick chart
    fig = go.Figure()
    
    # Add candlestick chart
    fig.add_trace(go.Candlestick(
        x=dates,
        open=opens,
        high=highs,
        low=lows,
        close=closes,
        increasing=dict(line=dict(color='#00c7b7'), fillcolor='rgba(0, 199, 183, 0.6)'),
        decreasing=dict(line=dict(color='#ff5757'), fillcolor='rgba(255, 87, 87, 0.6)'),
        name='Price'
    ))
    
    # Add volume bars below
    fig.add_trace(go.Bar(
        x=dates,
        y=volumes,
        marker=dict(color='rgba(75, 183, 255, 0.3)'),
        opacity=0.3,
        name='Volume',
        yaxis='y2'
    ))
    
    # Add a glowing SMA line
    sma_period = 10
    closes_series = pd.Series(closes)
    sma = closes_series.rolling(window=sma_period).mean()
    
    fig.add_trace(go.Scatter(
        x=dates,
        y=sma,
        mode='lines',
        line=dict(color='#ffb300', width=2),
        name=f'SMA {sma_period}'
    ))
    
    # Update layout for a clean, modern look
    fig.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        margin=dict(l=0, r=0, t=0, b=0),
        height=300,
        xaxis=dict(
            showgrid=False,
            zeroline=False,
            visible=False,
            rangeslider=dict(visible=False)
        ),
        yaxis=dict(
            showgrid=False,
            zeroline=False,
            visible=False,
            side='right'
        ),
        yaxis2=dict(
            showgrid=False,
            zeroline=False,
            visible=False,
            overlaying='y',
            range=[0, max(volumes) * 3],
            side='right'
        ),
        showlegend=False,
        hovermode=False
    )
    
    return fig

# Function for login animation
def show_loading_animation():
    # Display a container for the animation
    animation_container = st.empty()
    
    with animation_container.container():
        st.markdown('<div class="fade-in"><h1 style="text-align: center;">JustTry Trading Bot</h1></div>', unsafe_allow_html=True)
        st.markdown('<div class="fade-in-delay-1"><h3 style="text-align: center;">Initializing AI Systems...</h3></div>', unsafe_allow_html=True)
        
        # Loading bar
        st.markdown('<div class="loading-bar fade-in-delay-2"></div>', unsafe_allow_html=True)
        
        # Show animated chart
        st.markdown('<div class="fade-in-delay-2 animate-chart chart-glow">', unsafe_allow_html=True)
        st.plotly_chart(generate_chart_data(), use_container_width=True, config={'displayModeBar': False})
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Status messages
        status_container = st.empty()
        statuses = [
            "Loading trading algorithms...",
            "Connecting to market data...",
            "Initializing AI prediction models...",
            "Syncing historical data...",
            "Preparing dashboard components...",
            "Ready to login!"
        ]
        
        for i, status in enumerate(statuses):
            # Add a delay between status messages
            time.sleep(0.8)
            progress = (i + 1) / len(statuses)
            status_container.markdown(
                f'<div style="text-align: center; color: #00c7b7;">{status}</div>'
                f'<div style="background: rgba(0,199,183,0.2); border-radius: 5px; height: 5px; margin: 10px 0;">'
                f'<div style="background: linear-gradient(90deg, #00c7b7, #4fc3f7); width: {progress*100}%; height: 100%; border-radius: 5px;"></div>'
                f'</div>',
                unsafe_allow_html=True
            )
    
    # After animation completes
    time.sleep(1)
    animation_container.empty()
    st.session_state.animation_complete = True

# Main app
def main():
    # If not logged in, show login screen
    if not st.session_state.logged_in:
        # Show animation first if it hasn't been shown yet
        if st.session_state.show_animation and not st.session_state.animation_complete:
            show_loading_animation()
            st.session_state.show_animation = False
            st.rerun()
        
        # After animation or if animation already shown
        col1, col2, col3 = st.columns([1, 2, 1])
        
        with col2:
            st.markdown('<div class="login-container">', unsafe_allow_html=True)
            
            # Title at the top (no logo image)
            st.markdown('<div style="text-align: center; margin-bottom: 20px;">'
                        '<h1 style="font-size: 2.5rem; margin-bottom: 5px; color: white; text-shadow: 0 0 10px rgba(0, 199, 183, 0.7);">JustTry Trading Bot</h1>'
                        '<p style="color: white; font-size: 1.2rem;">AI-Powered Trading Platform</p>'
                        '</div>', unsafe_allow_html=True)
            
            # Custom tab styling with more visible text
            st.markdown("""
            <style>
                .stTabs [data-baseweb="tab-list"] {
                    gap: 2px;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
                }
                
                .stTabs [data-baseweb="tab"] {
                    height: 50px;
                    white-space: pre-wrap;
                    border-radius: 4px 4px 0px 0px;
                    color: white !important;
                    font-size: 16px;
                    font-weight: 500;
                }
                
                .stTabs [aria-selected="true"] {
                    background-color: rgba(0, 199, 183, 0.2) !important;
                    border-bottom: 3px solid #00c7b7 !important;
                    color: white !important;
                    font-weight: bold;
                }
            </style>
            """, unsafe_allow_html=True)
            
            # Login/Signup tabs
            tab1, tab2 = st.tabs(["Login", "Create Account"])
            
            # Login Tab
            with tab1:
                username = st.text_input("Username", key="login_username")
                password = st.text_input("Password", type="password", key="login_password")
                
                col1, col2 = st.columns(2)
                with col1:
                    login_button = st.button("Login", use_container_width=True)
                with col2:
                    demo_button = st.button("Try Demo", use_container_width=True)
                
                # Remember me and forgot password
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("""
                    <style>
                        .stCheckbox > label {
                            color: white !important;
                            font-size: 0.95rem !important;
                        }
                        .stCheckbox > label:hover {
                            color: #00c7b7 !important;
                        }
                    </style>
                    """, unsafe_allow_html=True)
                    st.checkbox("Remember me")
                with col2:
                    st.markdown('<div style="text-align: right;"><a href="#" style="color: #00c7b7; text-decoration: none; font-size: 0.95rem; font-weight: 500;">Forgot password?</a></div>', unsafe_allow_html=True)
                
                # Error message for failed login
                if st.session_state.login_attempts > 0:
                    st.error("Invalid username or password. Please try again.")
            
            # Signup Tab
            with tab2:
                new_username = st.text_input("Choose Username", key="signup_username")
                new_email = st.text_input("Email Address", key="signup_email")
                new_password = st.text_input("Create Password", type="password", key="signup_password")
                confirm_password = st.text_input("Confirm Password", type="password", key="signup_confirm")
                
                # Password strength indicator
                if new_password:
                    # Simple password strength checker
                    strength = 0
                    feedback = ""
                    
                    if len(new_password) >= 8:
                        strength += 1
                    if any(c.isdigit() for c in new_password):
                        strength += 1
                    if any(c.isupper() for c in new_password) and any(c.islower() for c in new_password):
                        strength += 1
                    if any(not c.isalnum() for c in new_password):
                        strength += 1
                    
                    strength_class = ""
                    if strength <= 1:
                        strength_class = "weak"
                        feedback = "Weak: Use 8+ characters with numbers and symbols"
                    elif strength <= 2:
                        strength_class = "medium"
                        feedback = "Medium: Add uppercase letters or symbols"
                    else:
                        strength_class = "strong"
                        feedback = "Strong password!"
                    
                    # Display strength indicator
                    st.markdown(f'''
                    <div class="password-strength">
                        <div class="strength-level {strength_class}"></div>
                    </div>
                    <div style="text-align: right; font-size: 0.8em; margin-top: 5px; color: white;">{feedback}</div>
                    ''', unsafe_allow_html=True)
                
                # Terms and conditions - add styling for better visibility
                st.markdown("""
                <style>
                    /* Make checkbox text white and more visible */
                    .stCheckbox > label {
                        color: white !important;
                        font-size: 0.95rem !important;
                    }
                    .stCheckbox > label:hover {
                        color: #00c7b7 !important;
                    }
                    /* Make the checkbox highlight color match our theme */
                    .stCheckbox > div[data-baseweb="checkbox"] div[role="checkbox"] {
                        border-color: #00c7b7 !important;
                    }
                    .stCheckbox > div[data-baseweb="checkbox"] div[role="checkbox"][aria-checked="true"] {
                        background-color: #00c7b7 !important;
                    }
                </style>
                """, unsafe_allow_html=True)
                terms_agreed = st.checkbox("I agree to the Terms of Service and Privacy Policy", key="terms")
                
                signup_button = st.button("Create Account", use_container_width=True, 
                                        disabled=not (new_username and new_email and new_password and 
                                                    confirm_password and terms_agreed))
                
                # Signup validation and error messages
                if signup_button:
                    if new_password != confirm_password:
                        st.error("Passwords do not match!")
                    elif new_username in st.session_state.users:
                        st.error("Username already exists!")
                    else:
                        # Create new user
                        st.session_state.users[new_username] = {
                            'password': new_password,
                            'email': new_email,
                            'created_at': datetime.now()
                        }
                        st.success("Account created successfully! You can now log in.")
            
            st.markdown('</div>', unsafe_allow_html=True)
            
            # Login logic
            if login_button:
                if username in st.session_state.users and st.session_state.users[username]['password'] == password:
                    st.session_state.logged_in = True
                    st.rerun()
                else:
                    st.session_state.login_attempts += 1
            
            # Demo login
            if demo_button:
                st.session_state.logged_in = True
                st.rerun()
        
        # Background image setup with animated floating candles
        try:
            # Get robot trader background image
            with open('assets/images/robot_trader.png', 'rb') as f:
                robot_image = base64.b64encode(f.read()).decode()
            
            # Create animated candle chart as an overlay
            candle_chart = generate_chart_data()
            chart_container = st.container()
            
            # Add full-screen background image
            st.markdown(f"""
            <style>
                /* Full-screen background image */
                .stApp {{
                    background-image: url(data:image/png;base64,{robot_image}) !important;
                    background-size: cover !important;
                    background-position: center !important;
                    background-repeat: no-repeat !important;
                }}
                
                /* Darker overlay for better readability and dimmer background */
                .background-overlay {{
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    z-index: -5;
                    background-color: rgba(5, 15, 30, 0.85);
                }}
                
                /* Floating animation for candles */
                @keyframes float-candles {{
                    0% {{ transform: translateY(0px); }}
                    50% {{ transform: translateY(-15px); }}
                    100% {{ transform: translateY(0px); }}
                }}
                
                /* Position the candlestick chart as a decorative background element */
                .floating-candles {{
                    position: fixed;
                    top: 50px;
                    right: -100px;
                    width: 600px;
                    height: 300px;
                    z-index: -3;
                    opacity: 0.3;
                    transform: rotate(-15deg);
                    animation: float-candles 8s ease-in-out infinite;
                }}
                
                /* Second floating candle chart */
                .floating-candles-2 {{
                    position: fixed;
                    bottom: 50px;
                    left: -100px;
                    width: 500px;
                    height: 250px;
                    z-index: -3;
                    opacity: 0.3;
                    transform: rotate(10deg);
                    animation: float-candles 10s ease-in-out infinite 1s;
                }}
                
                /* Glowing line effects */
                .glow-line {{
                    position: fixed;
                    height: 2px;
                    background: linear-gradient(90deg, transparent, #00c7b7, #4fc3f7, transparent);
                    z-index: -4;
                    animation: pulse 4s infinite;
                }}
            </style>
            
            <div class="background-overlay"></div>
            
            <!-- Animated glowing lines -->
            <div class="glow-line" style="top: 25%; left: 0; width: 100%; animation-delay: 0s;"></div>
            <div class="glow-line" style="top: 45%; left: 0; width: 80%; animation-delay: 1s;"></div>
            <div class="glow-line" style="top: 65%; left: 20%; width: 80%; animation-delay: 2s;"></div>
            <div class="glow-line" style="top: 85%; left: 30%; width: 70%; animation-delay: 1.5s;"></div>
            """, unsafe_allow_html=True)
            
            # Add floating candle charts in the background
            with chart_container:
                # Use the empty trick to position these absolutely
                floating_candles1 = st.empty()
                floating_candles2 = st.empty()
                
                floating_candles1.markdown('<div class="floating-candles"></div>', unsafe_allow_html=True)
                floating_candles2.markdown('<div class="floating-candles-2"></div>', unsafe_allow_html=True)
                
                # Add actual candle charts using Plotly in specific locations
                with st.container():
                    st.markdown('<style>.stPlotlyChart {position: absolute; z-index: -2;}</style>', unsafe_allow_html=True)
                    # Main animated chart in top-right
                    st.plotly_chart(candle_chart, use_container_width=True, config={'displayModeBar': False})
                    # Second chart with different data pattern in bottom-left
                    st.plotly_chart(generate_chart_data(), use_container_width=True, config={'displayModeBar': False})
        
        except Exception as e:
            # Fallback in case image isn't found
            st.error(f"Error loading background: {e}")
            st.markdown("""
            <div class="robot-container">
                <div class="chart-line"></div>
            </div>
            """, unsafe_allow_html=True)
        
        # Description at the bottom
        st.markdown("""
        <div style="text-align: center; max-width: 600px; margin: 0 auto; color: white;">
            <h4 style="color: white; font-size: 1.3rem; margin-bottom: 10px;">Advanced Trading with AI</h4>
            <p style="font-size: 1rem; line-height: 1.5;">JustTry Trading Bot combines cutting-edge artificial intelligence with powerful technical analysis to help you make better trading decisions. Our platform provides real-time market data, automated trading signals, and comprehensive analytics.</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Animated features section
        st.markdown("<h3 style='text-align: center; margin-top: 30px; color: white; font-size: 1.8rem;'>Key Features</h3>", unsafe_allow_html=True)
        
        features_col1, features_col2, features_col3 = st.columns(3)
        
        with features_col1:
            st.markdown("""
            <div style="text-align: center; padding: 20px; background: rgba(0,0,0,0.3); border-radius: 10px; height: 100%; border: 1px solid rgba(0, 199, 183, 0.2);">
                <div style="font-size: 30px; margin-bottom: 10px; color: #00c7b7;">📊</div>
                <h4 style="color: white; margin-bottom: 10px;">Real-time Analytics</h4>
                <p style="color: #d4d4d4; font-size: 0.95em; line-height: 1.4;">Track market movements and make informed decisions with live data and powerful visualization tools.</p>
            </div>
            """, unsafe_allow_html=True)
            
        with features_col2:
            st.markdown("""
            <div style="text-align: center; padding: 20px; background: rgba(0,0,0,0.3); border-radius: 10px; height: 100%; border: 1px solid rgba(0, 199, 183, 0.2);">
                <div style="font-size: 30px; margin-bottom: 10px; color: #00c7b7;">🤖</div>
                <h4 style="color: white; margin-bottom: 10px;">AI-Powered Trading</h4>
                <p style="color: #d4d4d4; font-size: 0.95em; line-height: 1.4;">Our machine learning algorithms analyze market patterns to generate high-probability trading signals.</p>
            </div>
            """, unsafe_allow_html=True)
            
        with features_col3:
            st.markdown("""
            <div style="text-align: center; padding: 20px; background: rgba(0,0,0,0.3); border-radius: 10px; height: 100%; border: 1px solid rgba(0, 199, 183, 0.2);">
                <div style="font-size: 30px; margin-bottom: 10px; color: #00c7b7;">📱</div>
                <h4 style="color: white; margin-bottom: 10px;">Multi-platform Support</h4>
                <p style="color: #d4d4d4; font-size: 0.95em; line-height: 1.4;">Access your trading dashboard from anywhere on desktop, tablet, or mobile devices.</p>
            </div>
            """, unsafe_allow_html=True)
    
    # If logged in, redirect to the main app
    else:
        # Redirect to main dashboard
        st.switch_page("app.py")

if __name__ == "__main__":
    main()