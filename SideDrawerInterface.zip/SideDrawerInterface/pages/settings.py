import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import time
import random
from assets.color_themes import themes, get_theme_css

# Page configuration
st.set_page_config(
    page_title="Settings",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Get theme and session state
if 'color_theme' not in st.session_state:
    st.session_state.color_theme = "Turquoise Gold"

# Custom CSS for styling with theme
try:
    with open("assets/style.css") as f:
        base_css = f.read()
    
    # Get theme CSS
    theme_css = get_theme_css(st.session_state.color_theme)
    
    # Combine base CSS with theme CSS
    st.markdown(f'<style>{base_css}\n{theme_css}</style>', unsafe_allow_html=True)
except Exception as e:
    st.error(f"Error loading styles: {e}")
    
# Additional custom CSS for settings page
custom_css = """
<style>
.settings-container {
    background-color: #1a2433;
    border-radius: 8px;
    padding: 25px;
    margin-bottom: 20px;
}
.settings-section {
    margin-bottom: 30px;
}
.settings-title {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 20px;
    color: white;
}
.settings-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}
.settings-label {
    color: #aaaaaa;
    font-size: 16px;
    font-weight: 500;
}
.settings-value {
    color: white;
    font-size: 16px;
    font-weight: 500;
    text-align: right;
}
.toggle-container {
    position: relative;
    width: 50px;
    height: 24px;
    border-radius: 12px;
    background-color: #333;
    overflow: hidden;
    cursor: pointer;
}
.toggle-on {
    background-color: #00c7b7;
}
.toggle-circle {
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    border-radius: 10px;
    background-color: white;
    transition: transform 0.3s;
}
.toggle-on .toggle-circle {
    transform: translateX(26px);
}
.settings-input {
    background-color: #1a2433;
    border: 1px solid #333;
    border-radius: 4px;
    color: white;
    padding: 8px 12px;
    width: 250px;
}
.change-password-btn {
    background-color: #1a2433;
    border: 1px solid #333;
    border-radius: 4px;
    color: white;
    padding: 10px 15px;
    cursor: pointer;
    text-align: center;
    transition: background-color 0.3s;
}
.change-password-btn:hover {
    background-color: #253344;
}
.pulse-indicator {
    display: flex;
    align-items: center;
    margin-top: 20px;
}
.pulse-circle {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background-color: #00c7b7;
    margin-right: 10px;
    animation: pulse 1.5s infinite;
}
@keyframes pulse {
    0% { opacity: 0.7; transform: scale(0.95); }
    50% { opacity: 1; transform: scale(1.05); }
    100% { opacity: 0.7; transform: scale(0.95); }
}
</style>
"""
st.markdown(custom_css, unsafe_allow_html=True)

# Initialize session state variables
if 'dark_theme' not in st.session_state:
    st.session_state.dark_theme = True
if 'language' not in st.session_state:
    st.session_state.language = "English"
if 'lot_size' not in st.session_state:
    st.session_state.lot_size = "0.01"
if 'risk_reward' not in st.session_state:
    st.session_state.risk_reward = "1:2"
if 'ai_assisted' not in st.session_state:
    st.session_state.ai_assisted = True
if 'execution_alerts' not in st.session_state:
    st.session_state.execution_alerts = True
if 'disconnect_warnings' not in st.session_state:
    st.session_state.disconnect_warnings = True
if 'mt5_connected' not in st.session_state:
    st.session_state.mt5_connected = True
if 'pulse_start_time' not in st.session_state:
    st.session_state.pulse_start_time = datetime.now() - timedelta(hours=3, minutes=5)

# Sidebar content
with st.sidebar:
    if 'sidebar_state' not in st.session_state:
        st.session_state.sidebar_state = 'expanded'
        
    if st.session_state.sidebar_state == 'expanded':
        st.markdown("<h2 style='text-align: center;'>Settings Controls</h2>", unsafe_allow_html=True)
        
        # Navigation
        st.markdown("### Navigation")
        pages = {
            "Trading Dashboard": "/",
            "Trade Execution": "/execution",
            "Analytics & Performance": "/analytics",
            "Settings": "/settings"
        }
        for page_name, page_url in pages.items():
            st.markdown(f"""
            <a href="{page_url}" target="_self" style="text-decoration: none;">
                <div style="background-color: #1a2433; 
                     padding: 10px; border-radius: 5px; margin-bottom: 5px;
                     border-left: 3px solid {'#f5b942' if page_url == '/settings' else '#00c7b7'};">
                    {page_name}
                </div>
            </a>
            """, unsafe_allow_html=True)
        
        # Theme Selector
        st.markdown("### Theme")
        theme_options = list(themes.keys())
        selected_theme = st.selectbox(
            "Color Theme", 
            theme_options,
            index=theme_options.index(st.session_state.color_theme)
        )
        
        if selected_theme != st.session_state.color_theme:
            st.session_state.color_theme = selected_theme
            st.rerun()
            
        # Connection status
        status_color = "#00c7b7" if st.session_state.mt5_connected else "#f5b942"
        status_text = "Connected" if st.session_state.mt5_connected else "Disconnected"
        st.markdown(f"""
        <div style='display: flex; align-items: center; margin-top: 20px;'>
            <div style='background-color: {status_color}; width: 10px; height: 10px; border-radius: 50%; margin-right: 10px;'></div>
            <span>MT5: {status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        # Collapse button
        if st.button("◀ Collapse Sidebar", use_container_width=True):
            st.session_state.sidebar_state = 'collapsed'
            st.rerun()
    else:
        # Collapsed sidebar state - just show expand button
        if st.button("▶", key="expand_sidebar"):
            st.session_state.sidebar_state = 'expanded'
            st.rerun()

# Create a header container with gradient background
st.markdown("""
<div style='background: linear-gradient(90deg, #1a2433 0%, #121721 100%); 
       padding: 10px; border-radius: 10px; margin-bottom: 15px; 
       box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); border-left: 4px solid #00c7b7;'>
""", unsafe_allow_html=True)

# Title with connection status within the container
col1, col2, col3 = st.columns([3, 1, 1])
with col1:
    st.markdown("<h1 style='margin-bottom: 0px;'>Settings</h1>", unsafe_allow_html=True)
with col2:
    status_color = "#00c7b7" if st.session_state.mt5_connected else "#f5b942"
    status_text = "Connected" if st.session_state.mt5_connected else "Disconnected"
    status_glow = "0 0 10px rgba(0, 199, 183, 0.7)" if st.session_state.mt5_connected else "0 0 10px rgba(245, 185, 66, 0.7)"
    st.markdown(f"""
    <div style='display: flex; align-items: center; margin-top: 20px;'>
        <div style='background-color: {status_color}; width: 12px; height: 12px; 
             border-radius: 50%; margin-right: 10px; box-shadow: {status_glow};
             animation: pulse 1.5s infinite;'></div>
        <span style='font-weight: 500;'>MT5: {status_text}</span>
    </div>
    <style>
    @keyframes pulse {{
        0% {{ opacity: 0.7; transform: scale(0.95); }}
        50% {{ opacity: 1; transform: scale(1.05); }}
        100% {{ opacity: 0.7; transform: scale(0.95); }}
    }}
    </style>
    """, unsafe_allow_html=True)
with col3:
    current_time = datetime.now().strftime('%H:%M:%S')
    st.markdown(f"""
    <div class='time-indicator'>
        <i class='fas fa-clock' style='margin-right: 5px;'></i> {current_time}
    </div>
    """, unsafe_allow_html=True)

# Close the header container
st.markdown("</div>", unsafe_allow_html=True)

# Main content for settings page
st.subheader("Settings")

# Create container for the settings with a better visual style
settings_container = st.container()
with settings_container:
    settings_col1, settings_col2 = st.columns([2, 1])

    with settings_col1:
        # General Preferences section
        st.markdown("## General Preferences")
        st.markdown("---")
        
        # Theme settings
        st.markdown("#### Theme Settings")
        dark_theme = st.toggle("Dark Theme", value=st.session_state.dark_theme)
        if dark_theme != st.session_state.dark_theme:
            st.session_state.dark_theme = dark_theme
            st.rerun()
        
        trading_view_integration = st.toggle("TradingView Integration", value=True)
        
        # Language selection
        languages = ["English", "Spanish", "French", "German", "Japanese"]
        language = st.selectbox("Language", languages, index=languages.index(st.session_state.language))
        if language != st.session_state.language:
            st.session_state.language = language
            st.rerun()
        
        # Trading Preferences section
        st.markdown("## Trading Preferences")
        st.markdown("---")
        
        # Lot size
        lot_size = st.text_input("Lot Size", value=st.session_state.lot_size)
        if lot_size != st.session_state.lot_size:
            st.session_state.lot_size = lot_size
        
        # Risk-to-Reward Ratio
        risk_reward = st.text_input("Risk-to-Reward Ratio", value=st.session_state.risk_reward)
        if risk_reward != st.session_state.risk_reward:
            st.session_state.risk_reward = risk_reward
        
        # AI-Assisted TP/SL
        ai_assisted = st.toggle("AI-Assisted TP/SL", value=st.session_state.ai_assisted)
        if ai_assisted != st.session_state.ai_assisted:
            st.session_state.ai_assisted = ai_assisted
        
        # Notification Settings section
        st.markdown("## Notification Settings")
        st.markdown("---")
        
        # Execution Alerts
        execution_alerts = st.toggle("Execution Alerts", value=st.session_state.execution_alerts)
        if execution_alerts != st.session_state.execution_alerts:
            st.session_state.execution_alerts = execution_alerts
        
        # Disconnect Warnings
        disconnect_warnings = st.toggle("Disconnect Warnings", value=st.session_state.disconnect_warnings)
        if disconnect_warnings != st.session_state.disconnect_warnings:
            st.session_state.disconnect_warnings = disconnect_warnings

    with settings_col2:
        # Security section
        st.markdown("## Security")
        st.markdown("---")
        
        # Change Password button with styling
        if st.button("Change Password", use_container_width=True):
            st.success("Password change initiated")
        
        # Broker settings
        st.markdown("#### Broker Credentials")
        login = st.text_input("Login", placeholder="Enter login")
        password = st.text_input("Password", placeholder="Enter password", type="password")
        broker = st.text_input("Broker", value="Exness")
        
        # Status indicator
        st.markdown("---")
        col1, col2 = st.columns([1, 5])
        with col1:
            st.markdown("##### Status:")
        with col2:
            st.markdown(f"Running for 3 hr 5 min")
        
        # Calculate the time running since pulse started
        running_time = datetime.now() - st.session_state.pulse_start_time
        hours, remainder = divmod(running_time.total_seconds(), 3600)
        minutes, seconds = divmod(remainder, 60)
        
        # Display a progress bar to visualize system health
        st.progress(0.85, text="System Health: 85%")
        
        # Add a status indicator
        if st.session_state.mt5_connected:
            st.success("✓ Connected to broker")
        else:
            st.error("✗ Disconnected from broker")
            
        if st.button("Check Connection"):
            with st.spinner("Checking connection..."):
                time.sleep(1)
                st.success("Connection verified successfully!")