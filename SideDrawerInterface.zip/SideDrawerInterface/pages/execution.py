import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import time
import random
from assets.color_themes import themes, get_theme_css

# Page configuration
st.set_page_config(
    page_title="Trade Execution",
    page_icon="🔄",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Get theme and session state
if 'color_theme' not in st.session_state:
    st.session_state.color_theme = "Turquoise Gold"

# Custom CSS for styling with theme
try:
    with open("assets/style.css") as f:
        base_css = f.read()
    
    # Get theme CSS
    theme_css = get_theme_css(st.session_state.color_theme)
    
    # Combine base CSS with theme CSS
    st.markdown(f'<style>{base_css}\n{theme_css}</style>', unsafe_allow_html=True)
except Exception as e:
    st.error(f"Error loading styles: {e}")
    
# Additional custom CSS for execution page
custom_css = """
<style>
.exec-container {
    background-color: #1a2433;
    border-radius: 8px;
    padding: 25px;
    margin-bottom: 20px;
}
.exec-row {
    display: flex;
    justify-content: space-between;
    padding: 15px 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
.exec-label {
    color: #aaaaaa;
    font-size: 16px;
    font-weight: 500;
}
.exec-value {
    color: white;
    font-size: 16px;
    font-weight: 500;
    text-align: right;
}
.exec-title {
    font-size: 32px;
    font-weight: bold;
    margin-bottom: 30px;
    padding-bottom: 15px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
.exec-button {
    background-color: #00c7b7;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    font-weight: bold;
    cursor: pointer;
    margin-top: 20px;
    text-align: center;
    width: 100%;
}
.exec-button:hover {
    background-color: #00a395;
}
.trade-status {
    margin-top: 20px;
    padding: 15px;
    background-color: rgba(0, 199, 183, 0.1);
    border-left: 4px solid #00c7b7;
    border-radius: 4px;
}
</style>
"""
st.markdown(custom_css, unsafe_allow_html=True)

# Initialize session state variables
if 'selected_pair' not in st.session_state:
    st.session_state.selected_pair = 'EUR/USD'
if 'mt5_connected' not in st.session_state:
    st.session_state.mt5_connected = True
if 'trade_executed' not in st.session_state:
    st.session_state.trade_executed = False
if 'last_trade_details' not in st.session_state:
    st.session_state.last_trade_details = {
        'symbol': 'EUR/USD',
        'entry_time': 'Apr 17, 2025 15:45',
        'entry_price': '1.0821',
        'sl': '1.0780',
        'tp': '1.0902',
        'take_profit_multiplier': 'TP = 4x SL',
        'lot_size': '0.01',
        'entry_reason': 'W Pattern + RSI Divergence',
        'source': 'Rules + AI Insight',
        'execution_time': 'Trade Executed',
        'broker_response': '432ms',
        'order_id': '#EUR2504171545'
    }

# Sidebar content
with st.sidebar:
    if 'sidebar_state' not in st.session_state:
        st.session_state.sidebar_state = 'expanded'
        
    if st.session_state.sidebar_state == 'expanded':
        st.markdown("<h2 style='text-align: center;'>Execution Controls</h2>", unsafe_allow_html=True)
        
        # Navigation
        st.markdown("### Navigation")
        pages = {
            "Trading Dashboard": "/",
            "Trade Execution": "/execution",
            "Analytics & Performance": "/analytics"
        }
        for page_name, page_url in pages.items():
            st.markdown(f"""
            <a href="{page_url}" target="_self" style="text-decoration: none;">
                <div style="background-color: #1a2433; 
                     padding: 10px; border-radius: 5px; margin-bottom: 5px;
                     border-left: 3px solid {'#f5b942' if page_url == '/execution' else '#00c7b7'};">
                    {page_name}
                </div>
            </a>
            """, unsafe_allow_html=True)
        
        # Theme Selector
        st.markdown("### Theme")
        theme_options = list(themes.keys())
        selected_theme = st.selectbox(
            "Color Theme", 
            theme_options,
            index=theme_options.index(st.session_state.color_theme)
        )
        
        if selected_theme != st.session_state.color_theme:
            st.session_state.color_theme = selected_theme
            st.rerun()
            
        # Trade Settings
        st.markdown("### Trade Settings")
        
        # Currency pair selection  
        currency_pairs = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'NZD/USD']
        selected_pair = st.selectbox("Select Pair", currency_pairs, index=currency_pairs.index(st.session_state.selected_pair))
        if selected_pair != st.session_state.selected_pair:
            st.session_state.selected_pair = selected_pair
            
        # Lot size slider
        lot_size = st.select_slider("Lot Size", options=['0.01', '0.05', '0.1', '0.5', '1.0'], value='0.01')
        
        # Risk percentage slider
        risk_percentage = st.slider("Risk (%)", 0.5, 5.0, 1.0, 0.1)
        
        # Take profit multiplier
        tp_multiplier = st.select_slider("TP Multiplier (x SL)", options=['1x', '2x', '3x', '4x', '5x'], value='4x')
        
        # Order type
        order_type = st.radio("Order Type", ["Market", "Limit", "Stop"], horizontal=True)
        
        # Trade direction
        trade_direction = st.radio("Direction", ["Buy", "Sell"], horizontal=True)
        
        # Connection status
        status_color = "#00c7b7" if st.session_state.mt5_connected else "#f5b942"
        status_text = "Connected" if st.session_state.mt5_connected else "Disconnected"
        st.markdown(f"""
        <div style='display: flex; align-items: center; margin-top: 20px;'>
            <div style='background-color: {status_color}; width: 10px; height: 10px; border-radius: 50%; margin-right: 10px;'></div>
            <span>MT5: {status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        # Collapse button
        if st.button("◀ Collapse Sidebar", use_container_width=True):
            st.session_state.sidebar_state = 'collapsed'
            st.rerun()
    else:
        # Collapsed sidebar state - just show expand button
        if st.button("▶", key="expand_sidebar"):
            st.session_state.sidebar_state = 'expanded'
            st.rerun()

# Create a header container with gradient background
st.markdown("""
<div style='background: linear-gradient(90deg, #1a2433 0%, #121721 100%); 
       padding: 10px; border-radius: 10px; margin-bottom: 15px; 
       box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); border-left: 4px solid #f5b942;'>
""", unsafe_allow_html=True)

# Title with connection status within the container
col1, col2, col3 = st.columns([3, 1, 1])
with col1:
    st.markdown("<h1 style='margin-bottom: 0px;'>Trade Execution</h1>", unsafe_allow_html=True)
with col2:
    status_color = "#00c7b7" if st.session_state.mt5_connected else "#f5b942"
    status_text = "Connected" if st.session_state.mt5_connected else "Disconnected"
    status_glow = "0 0 10px rgba(0, 199, 183, 0.7)" if st.session_state.mt5_connected else "0 0 10px rgba(245, 185, 66, 0.7)"
    st.markdown(f"""
    <div style='display: flex; align-items: center; margin-top: 20px;'>
        <div style='background-color: {status_color}; width: 12px; height: 12px; 
             border-radius: 50%; margin-right: 10px; box-shadow: {status_glow};
             animation: pulse 1.5s infinite;'></div>
        <span style='font-weight: 500;'>MT5: {status_text}</span>
    </div>
    <style>
    @keyframes pulse {{
        0% {{ opacity: 0.7; transform: scale(0.95); }}
        50% {{ opacity: 1; transform: scale(1.05); }}
        100% {{ opacity: 0.7; transform: scale(0.95); }}
    }}
    </style>
    """, unsafe_allow_html=True)
with col3:
    current_time = datetime.now().strftime('%H:%M:%S')
    st.markdown(f"""
    <div class='time-indicator'>
        <i class='fas fa-clock' style='margin-right: 5px;'></i> {current_time}
    </div>
    """, unsafe_allow_html=True)

# Close the header container
st.markdown("</div>", unsafe_allow_html=True)

# Function to execute the trade
def execute_trade():
    # Simulate a trade execution
    with st.spinner('Executing trade...'):
        time.sleep(1.5)  # Simulate network delay
        
        # Update the last trade details
        now = datetime.now()
        st.session_state.last_trade_details = {
            'symbol': st.session_state.selected_pair,
            'entry_time': now.strftime('%b %d, %Y %H:%M'),
            'entry_price': '1.0821' if st.session_state.selected_pair == 'EUR/USD' else str(round(random.uniform(1.0, 2.0), 4)),
            'sl': '1.0780' if st.session_state.selected_pair == 'EUR/USD' else str(round(random.uniform(0.9, 1.9), 4)),
            'tp': '1.0902' if st.session_state.selected_pair == 'EUR/USD' else str(round(random.uniform(1.1, 2.1), 4)),
            'take_profit_multiplier': 'TP = 4x SL',
            'lot_size': '0.01',  # Default value
            'entry_reason': 'W Pattern + RSI Divergence',
            'source': 'Rules + AI Insight',
            'execution_time': 'Trade Executed',
            'broker_response': f'{random.randint(200, 800)}ms',
            'order_id': f'#{st.session_state.selected_pair.replace("/", "")}{now.strftime("%y%m%d%H%M")}'
        }
        
        st.session_state.trade_executed = True
        
        return True

# Main content - Create the trade execution container
trade_columns = st.columns([2, 1])

with trade_columns[0]:
    # Trade execution form
    st.markdown("""
    <div class="exec-container">
        <div class="exec-title">New Trade Order</div>
    """, unsafe_allow_html=True)
    
    # Form for trade execution
    with st.form("trade_execution_form"):
        col1, col2 = st.columns(2)
        
        # Define currency pairs
        currency_pairs = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'NZD/USD']
        
        with col1:
            symbol = st.selectbox("Symbol", currency_pairs, index=currency_pairs.index(st.session_state.selected_pair))
            entry_price = st.text_input("Entry Price", "1.0821")
            stop_loss = st.text_input("Stop Loss (SL)", "1.0780")
            risk_amount = st.text_input("Risk Amount ($)", "100")
        
        with col2:
            direction = st.radio("Direction", ["Buy", "Sell"], horizontal=True)
            take_profit = st.text_input("Take Profit (TP)", "1.0902")
            lot_size = st.text_input("Lot Size", "0.01")
            reason = st.selectbox("Entry Reason", ["W Pattern + RSI Divergence", "Support/Resistance", "Trend Confirmation", "Breakout", "Pullback"])
        
        # Include notes text area that spans both columns
        notes = st.text_area("Notes (Optional)", placeholder="Add any additional notes about this trade here...")
        
        # Submit button
        submitted = st.form_submit_button("Execute Trade")
        
        if submitted:
            # Get the lot size from the form for the execute_trade function
            success = execute_trade()
            if success:
                st.success("Trade executed successfully!")
                st.rerun()
    
    st.markdown("</div>", unsafe_allow_html=True)

with trade_columns[1]:
    # Recent trade or execution details
    st.markdown("""
    <div class="exec-container">
        <div class="exec-title">Last Trade Details</div>
    """, unsafe_allow_html=True)
    
    # If we have the last trade details, show them
    if st.session_state.last_trade_details:
        details = st.session_state.last_trade_details
        
        # Prepare the details
        exec_rows = [
            ("Symbol", details['symbol']),
            ("Entry Time", details['entry_time']),
            ("Entry Price", details['entry_price']),
            ("SL", details['sl']),
            ("TP", details['tp']),
            ("Take Profit Multiplier", details['take_profit_multiplier']),
            ("Lot Size", details['lot_size']),
            ("Entry Reason", details['entry_reason']),
            ("Source", details['source']),
            ("Execution Time", details['execution_time']),
            ("Broker Response", details['broker_response']),
            ("Order ID", details['order_id']),
        ]
        
        # Display each row
        for label, value in exec_rows:
            st.markdown(f"""
            <div class="exec-row">
                <div class="exec-label">{label}</div>
                <div class="exec-value">{value}</div>
            </div>
            """, unsafe_allow_html=True)
        
        # Add a close button
        if st.button("Close Position", use_container_width=True):
            st.warning("Position closed!")
    
    else:
        st.info("No recent trades executed.")
    
    st.markdown("</div>", unsafe_allow_html=True)

# Show a success message if the trade was just executed
if st.session_state.trade_executed:
    st.markdown("""
    <div class="trade-status">
        <b>Trade successfully executed!</b> Your order has been sent to the broker and confirmed.
    </div>
    """, unsafe_allow_html=True)
    # Reset the flag
    st.session_state.trade_executed = False