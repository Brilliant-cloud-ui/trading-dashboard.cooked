import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import time
import random
from assets.color_themes import themes, get_theme_css

# Page configuration
st.set_page_config(
    page_title="Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Get theme and session state
if 'color_theme' not in st.session_state:
    st.session_state.color_theme = "Turquoise Gold"

# Custom CSS for styling with theme
try:
    with open("assets/style.css") as f:
        base_css = f.read()
    
    # Get theme CSS
    theme_css = get_theme_css(st.session_state.color_theme)
    
    # Combine base CSS with theme CSS
    st.markdown(f'<style>{base_css}\n{theme_css}</style>', unsafe_allow_html=True)
except Exception as e:
    st.error(f"Error loading styles: {e}")
    
# Additional custom CSS for analytics page
custom_css = """
<style>
.metric-card {
    background-color: #1a2433;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
}
.metric-title {
    color: #aaaaaa;
    font-size: 16px;
    margin-bottom: 10px;
}
.metric-value {
    color: white;
    font-size: 36px;
    font-weight: bold;
}
.metric-icon {
    margin-bottom: 10px;
    color: #00c7b7;
    font-size: 24px;
}
.time-filter {
    background-color: #1a2433;
    border-radius: 8px;
    padding: 12px 20px;
    color: white;
    border: 1px solid #2c3242;
}
.negative-metric {
    color: #f5b942;
}
.positive-metric {
    color: #00c7b7;
}
</style>
"""
st.markdown(custom_css, unsafe_allow_html=True)

# Initialize session state variables
if 'selected_pair' not in st.session_state:
    st.session_state.selected_pair = 'EUR/USD'
if 'selected_timeframe' not in st.session_state:
    st.session_state.selected_timeframe = '1H'
if 'mt5_connected' not in st.session_state:
    st.session_state.mt5_connected = True

# Sidebar content
with st.sidebar:
    if 'sidebar_state' not in st.session_state:
        st.session_state.sidebar_state = 'expanded'
        
    if st.session_state.sidebar_state == 'expanded':
        st.markdown("<h2 style='text-align: center;'>Analytics Controls</h2>", unsafe_allow_html=True)
        
        # Navigation
        st.markdown("### Navigation")
        pages = {
            "Trading Dashboard": "/",
            "Trade Execution": "/execution",
            "Analytics & Performance": "/analytics",
            "Settings": "/settings"
        }
        for page_name, page_url in pages.items():
            st.markdown(f"""
            <a href="{page_url}" target="_self" style="text-decoration: none;">
                <div style="background-color: #1a2433; 
                     padding: 10px; border-radius: 5px; margin-bottom: 5px;
                     border-left: 3px solid {'#00c7b7' if page_url == '/analytics' else '#f5b942'};">
                    {page_name}
                </div>
            </a>
            """, unsafe_allow_html=True)
        
        # Theme Selector
        st.markdown("### Theme")
        theme_options = list(themes.keys())
        selected_theme = st.selectbox(
            "Color Theme", 
            theme_options,
            index=theme_options.index(st.session_state.color_theme)
        )
        
        if selected_theme != st.session_state.color_theme:
            st.session_state.color_theme = selected_theme
            st.rerun()
        
        st.markdown("### Time Period")
        time_period = st.selectbox("Select Period", ["This Week", "This Month", "This Quarter", "This Year", "All Time"], index=3)
        
        st.markdown("### Currency Pairs")
        selected_pairs = st.multiselect(
            "Select Pairs", 
            ['EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'NZD/USD'],
            default=['EUR/USD', 'GBP/USD']
        )
        
        st.markdown("### Data Filters")
        show_only_profitable = st.checkbox("Show Only Profitable Trades", value=False)
        min_trade_size = st.slider("Minimum Trade Size", 0.01, 1.0, 0.01, 0.01)
        
        # Connection status
        status_color = "green" if st.session_state.mt5_connected else "red"
        status_text = "Connected" if st.session_state.mt5_connected else "Disconnected"
        st.markdown(f"""
        <div style='display: flex; align-items: center; margin-top: 20px;'>
            <div style='background-color: {status_color}; width: 10px; height: 10px; border-radius: 50%; margin-right: 10px;'></div>
            <span>MT5: {status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        # Collapse button
        if st.button("◀ Collapse Sidebar", use_container_width=True):
            st.session_state.sidebar_state = 'collapsed'
            st.rerun()
    else:
        # Collapsed sidebar state - just show expand button
        if st.button("▶", key="expand_sidebar"):
            st.session_state.sidebar_state = 'expanded'
            st.rerun()

# Create a header container with gradient background
st.markdown("""
<div style='background: linear-gradient(90deg, #1a2433 0%, #121721 100%); 
       padding: 10px; border-radius: 10px; margin-bottom: 15px; 
       box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); border-left: 4px solid #00c7b7;'>
""", unsafe_allow_html=True)

# Title with connection status within the container
col1, col2, col3 = st.columns([3, 1, 1])
with col1:
    st.markdown("<h1 style='margin-bottom: 0px;'>Analytics Dashboard</h1>", unsafe_allow_html=True)
with col2:
    status_color = "#00c7b7" if st.session_state.mt5_connected else "#f5b942"
    status_text = "Connected" if st.session_state.mt5_connected else "Disconnected"
    status_glow = "0 0 10px rgba(0, 199, 183, 0.7)" if st.session_state.mt5_connected else "0 0 10px rgba(245, 185, 66, 0.7)"
    st.markdown(f"""
    <div style='display: flex; align-items: center; margin-top: 20px;'>
        <div style='background-color: {status_color}; width: 12px; height: 12px; 
             border-radius: 50%; margin-right: 10px; box-shadow: {status_glow};
             animation: pulse 1.5s infinite;'></div>
        <span style='font-weight: 500;'>MT5: {status_text}</span>
    </div>
    <style>
    @keyframes pulse {{
        0% {{ opacity: 0.7; transform: scale(0.95); }}
        50% {{ opacity: 1; transform: scale(1.05); }}
        100% {{ opacity: 0.7; transform: scale(0.95); }}
    }}
    </style>
    """, unsafe_allow_html=True)
with col3:
    current_time = datetime.now().strftime('%H:%M:%S')
    st.markdown(f"""
    <div class='time-indicator'>
        <i class='fas fa-clock' style='margin-right: 5px;'></i> {current_time}
    </div>
    """, unsafe_allow_html=True)

# Close the header container
st.markdown("</div>", unsafe_allow_html=True)

# Time filter options
col1, col2 = st.columns(2)
with col1:
    filter_option = st.selectbox(
        "Filter By:",
        ["All", "This Week", "This Month", "This Quarter", "This Year"],
        label_visibility="collapsed"
    )
with col2:
    period_option = st.selectbox(
        "Time Period:",
        ["This Month", "Last Month", "Last 3 Months", "Last 6 Months", "Last Year"],
        label_visibility="collapsed"
    )

# Key metrics in a grid
# First row - 4 metric cards
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 9H7V20H3V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M10 4H14V20H10V4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M17 13H21V20H17V13Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="metric-title">Total Trades</div>
        <div class="metric-value">120</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 11.08V12C21.9988 14.1564 21.3005 16.2547 20.0093 17.9818C18.7182 19.709 16.9033 20.9725 14.8354 21.5839C12.7674 22.1953 10.5573 22.1219 8.53447 21.3746C6.51168 20.6273 4.78465 19.2461 3.61096 17.4371C2.43727 15.628 1.87979 13.4881 2.02168 11.3363C2.16356 9.18455 2.99721 7.13631 4.39828 5.49706C5.79935 3.85781 7.69279 2.71537 9.79619 2.24013C11.8996 1.7649 14.1003 1.98232 16.07 2.85999" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M22 4L12 14.01L9 11.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="metric-title">Win Rate</div>
        <div class="metric-value">61,7%</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M9 22V12H15V22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="metric-title">Cumulative Profit %</div>
        <div class="metric-value">25,0%</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 4H3C1.89543 4 1 4.89543 1 6V18C1 19.1046 1.89543 20 3 20H21C22.1046 20 23 19.1046 23 18V6C23 4.89543 22.1046 4 21 4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M1 10H23" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="metric-title">Sharpe Ratio</div>
        <div class="metric-value">1,68</div>
    </div>
    """, unsafe_allow_html=True)

# Second row - 2 metric cards
col1, col2, col3 = st.columns([1, 1, 2])

with col1:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-icon negative-metric">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="metric-title">Max Drawdown</div>
        <div class="metric-value negative-metric">5,8%</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-icon positive-metric">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 12H18L15 21L9 3L6 12H2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="metric-title">Current Equity Growth</div>
        <div class="metric-value positive-metric">20,5%</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 4H3C1.89543 4 1 4.89543 1 6V18C1 19.1046 1.89543 20 3 20H21C22.1046 20 23 19.1046 23 18V6C23 4.89543 22.1046 4 21 4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M1 10H23" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <div class="metric-title">Sharpe Ratio</div>
        <div class="metric-value">1,68</div>
    </div>
    """, unsafe_allow_html=True)

# Cumulative profit chart
st.markdown("""
<div style="background-color: #1a2433; border-radius: 8px; padding: 20px; margin-top: 20px;">
    <h3 style="margin-bottom: 20px; color: white;">Cumulative Profit %</h3>
""", unsafe_allow_html=True)

# Create profit growth line chart
# Generate data points from 0% to 20% with growth curve
trades = list(range(1, 38))
profit_curve = [0.0]
for i in range(1, len(trades)):
    if i < 5:
        # Slow initial growth
        increment = 0.8 + (i * 0.2)
    elif i < 10:
        # Accelerating growth
        increment = 1.0 + (i * 0.1)
    elif i < 20:
        # Stability with small growth
        increment = 0.5 + (i * 0.03)
    elif i < 30:
        # Rapid growth phase
        increment = 1.2 + ((i-20) * 0.15)
    else:
        # Continued growth at slower pace
        increment = 0.8 + ((i-30) * 0.05)
    
    # Add randomness to make it look natural
    random_factor = 0.7 + (random.random() * 0.6)
    new_value = profit_curve[-1] + (increment * random_factor)
    profit_curve.append(float(new_value))

# Scale to proper percentage range (0-20%)
max_value = max(profit_curve)
profit_curve = [(x / max_value) * 20 for x in profit_curve]

# Create figure
profit_fig = go.Figure()

# Add profit line
profit_fig.add_trace(go.Scatter(
    x=trades,
    y=profit_curve,
    mode='lines',
    name='Cumulative Profit',
    line=dict(color='#00c7b7', width=3, shape='spline'),
    fill='tozeroy',
    fillcolor='rgba(0, 199, 183, 0.1)'
))

# Update layout for better appearance
profit_fig.update_layout(
    height=400,
    margin=dict(l=20, r=20, t=10, b=20),
    paper_bgcolor='rgba(0,0,0,0)',
    plot_bgcolor='rgba(0,0,0,0)',
    font=dict(color='white', size=12),
    showlegend=False,
    xaxis=dict(
        showgrid=True,
        gridcolor='rgba(255, 255, 255, 0.05)',
        zeroline=False,
        title="",
        tickvals=[1, 3, 5, 7, 10, 15, 22, 29, 35, 37],
        tickfont=dict(size=12),
    ),
    yaxis=dict(
        showgrid=True,
        gridcolor='rgba(255, 255, 255, 0.05)',
        zeroline=False,
        title="",
        ticksuffix="%",
        range=[0, 20],
        tickvals=[0, 5, 10, 15, 20],
        ticktext=["0%", "5%", "10%", "15%", "20%"],
        tickfont=dict(size=12),
    )
)

# Display profit chart
st.plotly_chart(profit_fig, use_container_width=True)

# Close the container div
st.markdown("</div>", unsafe_allow_html=True)

# No longer needed as we updated the layout

# Additional metrics from the second reference image
st.subheader("Additional Analytics")

# Top metrics with trends (3 metric cards with sparklines)
col1, col2, col3 = st.columns(3)

with col1:
    # Positive metric with sparkline
    st.markdown("""
    <div style="background-color: #1a2433; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
        <div style="color: #888; font-size: 12px; margin-bottom: 5px;">TOTAL CUSTOMERS</div>
        <div style="font-size: 28px; font-weight: bold; margin-bottom: 10px;">12,132</div>
        <div style="display: flex; justify-content: space-between; align-items: flex-end;">
            <div style="color: #00c7b7; display: flex; align-items: center;">
                <span style="font-size: 18px; margin-right: 5px;">↑</span>
                <span>+12%</span>
            </div>
            <div>
                <svg width="100" height="30" viewBox="0 0 100 30">
                    <path d="M0,15 Q10,5 20,10 T40,5 T60,15 T80,5 T100,10" stroke="#00c7b7" stroke-width="2" fill="none" />
                </svg>
            </div>
        </div>
        <div style="color: #666; font-size: 11px; margin-top: 5px;">From the last month</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    # Negative metric with sparkline
    st.markdown("""
    <div style="background-color: #1a2433; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
        <div style="color: #888; font-size: 12px; margin-bottom: 5px;">TOTAL CUSTOMERS</div>
        <div style="font-size: 28px; font-weight: bold; margin-bottom: 10px;">2,982</div>
        <div style="display: flex; justify-content: space-between; align-items: flex-end;">
            <div style="color: #f5b942; display: flex; align-items: center;">
                <span style="font-size: 18px; margin-right: 5px;">↓</span>
                <span>-2.12%</span>
            </div>
            <div>
                <svg width="100" height="30" viewBox="0 0 100 30">
                    <path d="M0,10 Q10,15 20,12 T40,20 T60,15 T80,25 T100,20" stroke="#f5b942" stroke-width="2" fill="none" />
                </svg>
            </div>
        </div>
        <div style="color: #666; font-size: 11px; margin-top: 5px;">From the last month</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    # Positive metric with sparkline
    st.markdown("""
    <div style="background-color: #1a2433; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
        <div style="color: #888; font-size: 12px; margin-bottom: 5px;">TOTAL CUSTOMERS</div>
        <div style="font-size: 28px; font-weight: bold; margin-bottom: 10px;">12,132</div>
        <div style="display: flex; justify-content: space-between; align-items: flex-end;">
            <div style="color: #00c7b7; display: flex; align-items: center;">
                <span style="font-size: 18px; margin-right: 5px;">↑</span>
                <span>+8.63%</span>
            </div>
            <div>
                <svg width="100" height="30" viewBox="0 0 100 30">
                    <path d="M0,15 Q10,5 20,10 T40,5 T60,15 T80,5 T100,10" stroke="#00c7b7" stroke-width="2" fill="none" />
                </svg>
            </div>
        </div>
        <div style="color: #666; font-size: 11px; margin-top: 5px;">From the last month</div>
    </div>
    """, unsafe_allow_html=True)

# Line graph and mobile session
col1, col2 = st.columns([3, 1])

with col1:
    # Create a container for the line graph
    st.markdown("""
    <div style="background-color: #1a2433; padding: 15px; border-radius: 8px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <div style="font-weight: bold;">Line Graph</div>
            <div>
                <select style="background-color: #1a2433; color: white; border: 1px solid #333; padding: 2px 10px; border-radius: 4px;">
                    <option>This Year</option>
                </select>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    # Create multi-line chart 
    months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP']
    
    # Generate sample data for two lines with crossing patterns
    reader_data = [150, 90, 130, 150, 110, 130, 150, 170, 130]
    viewer_data = [100, 140, 110, 130, 160, 130, 100, 130, 160]
    
    fig = go.Figure()
    
    # Add first line (green)
    fig.add_trace(go.Scatter(
        x=months,
        y=reader_data,
        mode='lines',
        name='Reader',
        line=dict(color='#00c7b7', width=2.5, shape='spline'),
    ))
    
    # Add second line (blue)
    fig.add_trace(go.Scatter(
        x=months,
        y=viewer_data,
        mode='lines',
        name='Viewer',
        line=dict(color='#4fc3f7', width=2.5, shape='spline'),
    ))
    
    # Add vertical highlight line at April
    fig.add_shape(
        type="line",
        x0="APR", 
        y0=0,
        x1="APR", 
        y1=200,
        line=dict(color="#ffffff", width=1, dash="dash"),
    )
    
    # Add marker at intersection point
    fig.add_trace(go.Scatter(
        x=["APR"],
        y=[130],
        mode='markers',
        marker=dict(color='#afff8d', size=10),
        showlegend=False
    ))
    
    # Update layout for dark theme
    fig.update_layout(
        height=300,
        margin=dict(l=10, r=10, t=0, b=20),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white', size=10),
        legend=dict(
            orientation="h",
            y=1.1,
            x=0,
            font=dict(size=10)
        ),
        xaxis=dict(
            showgrid=True,
            gridcolor='rgba(255, 255, 255, 0.05)',
            zeroline=False,
            tickfont=dict(size=10),
        ),
        yaxis=dict(
            showgrid=True,
            gridcolor='rgba(255, 255, 255, 0.05)',
            zeroline=False,
            range=[0, 200],
            tickvals=[0, 50, 100, 150, 200],
            tickfont=dict(size=10),
        )
    )
    
    # Display chart
    st.plotly_chart(fig, use_container_width=True)
    
    # Close container
    st.markdown("</div>", unsafe_allow_html=True)

with col2:
    # Create a container for the mobile session
    st.markdown("""
    <div style="background-color: #1a2433; padding: 15px; border-radius: 8px;">
        <div style="font-weight: bold; margin-bottom: 15px;">Mobile Session</div>
    """, unsafe_allow_html=True)
    
    # Create a gauge chart
    gauge_fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=38.4,
        title={'text': "Weekly Analytics", 'font': {'size': 14, 'color': 'white'}},
        number={'suffix': "%", 'font': {'size': 24, 'color': 'white'}},
        gauge={
            'axis': {'range': [None, 100], 'tickwidth': 0, 'tickcolor': "white"},
            'bar': {'color': "#00c7b7"},
            'bgcolor': "rgba(0,0,0,0)",
            'borderwidth': 0,
            'steps': [
                {'range': [0, 38.4], 'color': '#00c7b7'},
                {'range': [38.4, 100], 'color': 'rgba(255, 255, 255, 0.1)'}
            ],
        }
    ))
    
    gauge_fig.update_layout(
        height=200,
        margin=dict(l=10, r=10, t=30, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        font={'color': "white", 'family': "Arial"},
    )
    
    st.plotly_chart(gauge_fig, use_container_width=True)
    
    # Platform analytics list
    platforms = ['Mobile', 'TV', 'Desktop', 'iOS', 'Android', 'Linux']
    visits = ['1,273 visits', '1,273 visits', '1,273 visits', '1,273 visits', '1,273 visits', '1,273 visits']
    percentages = ['35%', '35%', '35%', '35%', '35%', '35%']
    
    for i in range(len(platforms)):
        st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 8px;">
            <div style="width: 14px; height: 14px; background-color: {'#00c7b7' if i == 0 or i == 3 or i == 4 else '#ffffff'}; border-radius: 3px; margin-right: 10px;"></div>
            <div style="flex-grow: 1; display: flex; justify-content: space-between;">
                <div>
                    <div style="font-weight: 500; font-size: 12px;">{platforms[i]}</div>
                    <div style="color: #888; font-size: 10px;">{visits[i]}</div>
                </div>
                <div style="background-color: rgba(255,255,255,0.1); padding: 2px 8px; border-radius: 10px; font-size: 12px; height: fit-content;">{percentages[i]}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    # Close container
    st.markdown("</div>", unsafe_allow_html=True)

# Data analytics cards (resembling the green and red cards in the reference)
st.subheader("Data Analytics")

col1, col2 = st.columns(2)

with col1:
    # Green metrics card
    green_card = """
    <div style="background-color: #1a2433; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
            <span style="color: #00c7b7; display: flex; align-items: center;">
                <svg width="20" height="20" viewBox="0 0 24 24" stroke="currentColor" fill="none" style="margin-right: 5px;">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
                </svg>
                Data Analytics
            </span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <div style="text-align: center;">
                <div style="color: #00c7b7; font-size: 24px; font-weight: bold;">50%</div>
                <div style="color: #888; font-size: 12px;">Overtime</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #00c7b7; font-size: 24px; font-weight: bold;">50%</div>
                <div style="color: #888; font-size: 12px;">Overtime</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #00c7b7; font-size: 24px; font-weight: bold;">50%</div>
                <div style="color: #888; font-size: 12px;">Overtime</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #00c7b7; font-size: 24px; font-weight: bold;">50%</div>
                <div style="color: #888; font-size: 12px;">Overtime</div>
            </div>
        </div>
        <div style="display: flex; align-items: center; margin-top: 20px;">
            <span style="background-color: rgba(0, 199, 183, 0.2); color: #00c7b7; padding: 5px 10px; border-radius: 4px; margin-right: 10px;">
                <span style="font-size: 18px;">↑</span> +12%
            </span>
            <span style="color: #888;">Report Today</span>
        </div>
    </div>
    """
    st.markdown(green_card, unsafe_allow_html=True)

with col2:
    # Red metrics card
    red_card = """
    <div style="background-color: #1a2433; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
            <span style="color: #f5b942; display: flex; align-items: center;">
                <svg width="20" height="20" viewBox="0 0 24 24" stroke="currentColor" fill="none" style="margin-right: 5px;">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0v-8m0 8l-8-8-4 4-6-6"/>
                </svg>
                Data Analytics
            </span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <div style="text-align: center;">
                <div style="color: #f5b942; font-size: 24px; font-weight: bold;">50%</div>
                <div style="color: #888; font-size: 12px;">Overtime</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #f5b942; font-size: 24px; font-weight: bold;">50%</div>
                <div style="color: #888; font-size: 12px;">Overtime</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #f5b942; font-size: 24px; font-weight: bold;">50%</div>
                <div style="color: #888; font-size: 12px;">Overtime</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #f5b942; font-size: 24px; font-weight: bold;">50%</div>
                <div style="color: #888; font-size: 12px;">Overtime</div>
            </div>
        </div>
        <div style="display: flex; align-items: center; margin-top: 20px;">
            <span style="background-color: rgba(245, 185, 66, 0.2); color: #f5b942; padding: 5px 10px; border-radius: 4px; margin-right: 10px;">
                <span style="font-size: 18px;">↓</span> -12%
            </span>
            <span style="color: #888;">Report Today</span>
        </div>
    </div>
    """
    st.markdown(red_card, unsafe_allow_html=True)