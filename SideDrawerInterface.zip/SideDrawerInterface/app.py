import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import time
import random
from utils import generate_candle_data, calculate_rsi, calculate_atr
from assets.color_themes import themes, get_theme_css

# Page configuration
st.set_page_config(
    page_title="Trading Dashboard",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Add theme selection to session state
if 'color_theme' not in st.session_state:
    st.session_state.color_theme = "Turquoise Gold"

# Custom CSS for styling with theme
try:
    with open("assets/style.css") as f:
        base_css = f.read()
    
    # Get theme CSS
    theme_css = get_theme_css(st.session_state.color_theme)
    
    # Combine base CSS with theme CSS
    st.markdown(f'<style>{base_css}\n{theme_css}</style>', unsafe_allow_html=True)
except Exception as e:
    st.error(f"Error loading styles: {e}")

# Sidebar toggle functionality
if 'sidebar_state' not in st.session_state:
    st.session_state.sidebar_state = 'expanded'

# Initialize session state variables
if 'selected_pair' not in st.session_state:
    st.session_state.selected_pair = 'EUR/USD'
if 'selected_timeframe' not in st.session_state:
    st.session_state.selected_timeframe = '1H'
if 'trade_log' not in st.session_state:
    st.session_state.trade_log = [
        {'time': '14:23', 'message': 'Scan on USDJPY - No setup found'},
        {'time': '14:24', 'message': 'Scan on EURUSD - W Pattern detected'},
        {'time': '14:24', 'message': 'BUY executed on EURUSD at 1.0820'}
    ]
if 'last_trade' not in st.session_state:
    st.session_state.last_trade = {
        'status': 'Trade Executed',
        'pair': 'GBP/USD',
        'direction': 'SELL',
        'lot_size': '0.01',
        'firm': 'Firm',
        'entry': '1.2760',
        'lat_size': '40 bl',
        'reason': 'W Pattern'
    }
if 'mt5_connected' not in st.session_state:
    st.session_state.mt5_connected = True

# Sidebar content
with st.sidebar:
    if st.session_state.sidebar_state == 'expanded':
        st.markdown("<h2 style='text-align: center;'>Trading Controls</h2>", unsafe_allow_html=True)
        
        # Navigation
        st.markdown("### Navigation")
        pages = {
            "Trading Dashboard": "/",
            "Trade Execution": "/execution",
            "Analytics & Performance": "/analytics",
            "Settings": "/settings"
        }
        for page_name, page_url in pages.items():
            st.markdown(f"""
            <a href="{page_url}" target="_self" style="text-decoration: none;">
                <div style="background-color: #1a2433; 
                     padding: 10px; border-radius: 5px; margin-bottom: 5px;
                     border-left: 3px solid {'#00c7b7' if page_url == '/' else '#f5b942'};">
                    {page_name}
                </div>
            </a>
            """, unsafe_allow_html=True)
        
        # Theme Selector
        st.markdown("### Theme")
        theme_options = list(themes.keys())
        selected_theme = st.selectbox(
            "Color Theme", 
            theme_options,
            index=theme_options.index(st.session_state.color_theme)
        )
        
        if selected_theme != st.session_state.color_theme:
            st.session_state.color_theme = selected_theme
            st.rerun()
        
        st.markdown("### Currency Pairs")
        currency_pairs = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'NZD/USD']
        selected_pair = st.selectbox("Select Pair", currency_pairs, index=currency_pairs.index(st.session_state.selected_pair))
        if selected_pair != st.session_state.selected_pair:
            st.session_state.selected_pair = selected_pair
            st.rerun()
        
        st.markdown("### Analysis Tools")
        indicators = st.multiselect("Technical Indicators", 
                                     ["RSI", "ATR", "MACD", "Bollinger Bands", "Moving Averages"],
                                     default=["RSI", "ATR"])
        
        st.markdown("### Trading Settings")
        risk_percentage = st.slider("Risk per Trade (%)", 0.5, 5.0, 1.0, 0.1)
        
        st.markdown("### Quick Actions")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🟢 Buy", use_container_width=True):
                new_log = {'time': datetime.now().strftime("%H:%M"), 'message': f'BUY executed on {st.session_state.selected_pair}'}
                st.session_state.trade_log.insert(0, new_log)
                st.session_state.last_trade = {
                    'status': 'Trade Executed',
                    'pair': st.session_state.selected_pair,
                    'direction': 'BUY',
                    'lot_size': '0.01',
                    'firm': 'Firm',
                    'entry': '1.0843',
                    'lat_size': '40 bl',
                    'reason': 'W Pattern'
                }
                st.rerun()
        
        with col2:
            if st.button("🔴 Sell", use_container_width=True):
                new_log = {'time': datetime.now().strftime("%H:%M"), 'message': f'SELL executed on {st.session_state.selected_pair}'}
                st.session_state.trade_log.insert(0, new_log)
                st.session_state.last_trade = {
                    'status': 'Trade Executed',
                    'pair': st.session_state.selected_pair,
                    'direction': 'SELL',
                    'lot_size': '0.01',
                    'firm': 'Firm',
                    'entry': '1.0843',
                    'lat_size': '40 bl',
                    'reason': 'W Pattern'
                }
                st.rerun()
        
        # Connection status
        status_color = "#00c7b7" if st.session_state.mt5_connected else "#f5b942"
        status_text = "Connected" if st.session_state.mt5_connected else "Disconnected"
        st.markdown(f"""
        <div style='display: flex; align-items: center; margin-top: 20px;'>
            <div style='background-color: {status_color}; width: 10px; height: 10px; border-radius: 50%; margin-right: 10px;'></div>
            <span>MT5: {status_text}</span>
        </div>
        """, unsafe_allow_html=True)
        
        # Collapse button
        if st.button("◀ Collapse Sidebar", use_container_width=True):
            st.session_state.sidebar_state = 'collapsed'
            st.rerun()
    else:
        # Collapsed sidebar state - just show expand button
        if st.button("▶", key="expand_sidebar"):
            st.session_state.sidebar_state = 'expanded'
            st.rerun()

# Main content
# Create a header container with gradient background
st.markdown("""
<div style='background: linear-gradient(90deg, #1a1f29 0%, #131722 100%); 
           padding: 10px; border-radius: 10px; margin-bottom: 15px; 
           box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); border-left: 4px solid #4da6ff;'>
""", unsafe_allow_html=True)

# Title with connection status within the container
col1, col2, col3 = st.columns([3, 1, 1])
with col1:
    st.markdown("<h1 style='margin-bottom: 0px;'>Trading Dashboard</h1>", unsafe_allow_html=True)
with col2:
    status_color = "#26a69a" if st.session_state.mt5_connected else "#ef5350"
    status_text = "Connected" if st.session_state.mt5_connected else "Disconnected"
    status_glow = "0 0 10px rgba(38, 166, 154, 0.7)" if st.session_state.mt5_connected else "0 0 10px rgba(239, 83, 80, 0.7)"
    st.markdown(f"""
    <div style='display: flex; align-items: center; margin-top: 20px;'>
        <div style='background-color: {status_color}; width: 12px; height: 12px; 
                 border-radius: 50%; margin-right: 10px; box-shadow: {status_glow};
                 animation: pulse 1.5s infinite;'></div>
        <span style='font-weight: 500;'>MT5: {status_text}</span>
    </div>
    <style>
    @keyframes pulse {{
        0% {{ opacity: 0.7; transform: scale(0.95); }}
        50% {{ opacity: 1; transform: scale(1.05); }}
        100% {{ opacity: 0.7; transform: scale(0.95); }}
    }}
    </style>
    """, unsafe_allow_html=True)
with col3:
    current_time = datetime.now().strftime('%H:%M:%S')
    st.markdown(f"""
    <div class='time-indicator'>
        <i class='fas fa-clock' style='margin-right: 5px;'></i> {current_time}
    </div>
    """, unsafe_allow_html=True)

# Close the header container
st.markdown("</div>", unsafe_allow_html=True)

# Chart header with pair selection and timeframe selection
col1, col2, col3 = st.columns([2, 2, 1])
with col1:
    st.markdown(f"<h2 style='margin-bottom: 0px;'>{st.session_state.selected_pair}</h2>", unsafe_allow_html=True)
with col2:
    # Timeframe selection
    timeframe_options = ["1min", "5min", "15min", "30min", "1H", "4H", "1D", "1M", "1Y"]
    # Create a dropdown for better UI with more timeframe options
    selected_tf = st.selectbox(
        "Timeframe", 
        timeframe_options, 
        index=timeframe_options.index(st.session_state.selected_timeframe),
        key="timeframe_selector",
        label_visibility="collapsed"
    )
    
    if selected_tf != st.session_state.selected_timeframe:
        st.session_state.selected_timeframe = selected_tf
        st.rerun()

# Chart section
# Create an animated loading spinner while generating data
with st.spinner('Loading chart data...'):
    # Generate sample data based on selected pair and timeframe
    candles = generate_candle_data(st.session_state.selected_pair, st.session_state.selected_timeframe, 100)
    rsi_data = calculate_rsi(candles['close'].values, 10)
    atr_data = calculate_atr(candles['high'].values, candles['low'].values, candles['close'].values, 14)

# Create chart container with improved styling
st.markdown("""
<div style='background: linear-gradient(90deg, #1a1f29 0%, #131722 100%); 
     padding: 10px; border-radius: 10px; margin-bottom: 15px; 
     box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); border-left: 4px solid #4da6ff;'>
""", unsafe_allow_html=True)

# Create subplots with enhanced styling
fig = make_subplots(
    rows=3, 
    cols=1, 
    shared_xaxes=True,
    vertical_spacing=0.05,
    row_heights=[0.6, 0.2, 0.2],
    subplot_titles=(
        f"<span style='color: white; font-weight: 600;'>{st.session_state.selected_pair} Price Chart</span>", 
        "<span style='color: white; font-weight: 600;'>RSI (10)</span>", 
        "<span style='color: white; font-weight: 600;'>ATR (14)</span>"
    )
)

# Add candlestick chart
fig.add_trace(
    go.Candlestick(
        x=candles.index,
        open=candles['open'],
        high=candles['high'],
        low=candles['low'],
        close=candles['close'],
        increasing_line_color='#26a69a', 
        decreasing_line_color='#ef5350',
        name='Price'
    ),
    row=1, col=1
)

# Add moving average
fig.add_trace(
    go.Scatter(
        x=candles.index,
        y=candles['close'].rolling(20).mean(),
        line=dict(color='blue', width=1),
        name='MA (20)'
    ),
    row=1, col=1
)

# Add RSI indicator
fig.add_trace(
    go.Scatter(
        x=candles.index,
        y=rsi_data,
        line=dict(color='white', width=1),
        name='RSI (10)'
    ),
    row=2, col=1
)

# Add overbought/oversold lines for RSI
fig.add_shape(
    type="line", line_color="gray", line_dash="dash", x0=candles.index[0], x1=candles.index[-1], y0=70, y1=70, row=2, col=1
)
fig.add_shape(
    type="line", line_color="gray", line_dash="dash", x0=candles.index[0], x1=candles.index[-1], y0=30, y1=30, row=2, col=1
)
fig.add_shape(
    type="line", line_color="gray", line_dash="dash", x0=candles.index[0], x1=candles.index[-1], y0=50, y1=50, row=2, col=1
)

# Add ATR indicator
fig.add_trace(
    go.Scatter(
        x=candles.index,
        y=atr_data,
        line=dict(color='white', width=1),
        name='ATR (14)'
    ),
    row=3, col=1
)

# Pattern annotation (example)
# Find a point to place the pattern annotation
mid_point = len(candles) // 2
fig.add_annotation(
    x=candles.index[mid_point],
    y=candles.iloc[mid_point]['high'] * 1.005,  # Using iloc to fix the FutureWarning
    text="W Pattern + RSI Divergence",
    showarrow=True,
    arrowhead=1,
    row=1, col=1
)

# Update layout with enhanced visual design
fig.update_layout(
    height=600,
    margin=dict(l=0, r=10, t=30, b=0),
    legend=dict(
        orientation="h", 
        yanchor="bottom", 
        y=1.02, 
        xanchor="left", 
        x=0,
        font=dict(color='white', size=12),
        bordercolor='#2c3242',
        borderwidth=1
    ),
    xaxis_rangeslider_visible=False,
    plot_bgcolor='#1a1f29',
    paper_bgcolor='#1a1f29',
    font=dict(color='white', family='Inter, sans-serif'),
    showlegend=False,
    hoverlabel=dict(
        bgcolor='#2c3242',
        font_size=14,
        font_family='Inter, sans-serif'
    ),
    dragmode='zoom',
    hovermode='x unified'
)

# Update y-axes with enhanced styling
fig.update_yaxes(
    gridcolor='rgba(128, 128, 128, 0.1)',
    tickfont=dict(family='Inter, sans-serif', size=10),
    zeroline=False,
    showspikes=True,  # Add spike lines for better navigation
    spikecolor='rgba(255, 255, 255, 0.3)',
    spikethickness=1,
    spikedash='dot',
    spikemode='across',
    row=1, col=1
)
fig.update_yaxes(
    gridcolor='rgba(128, 128, 128, 0.1)',
    range=[0, 100],
    tickfont=dict(family='Inter, sans-serif', size=10),
    zeroline=False,
    # Add colored bands for RSI zones
    layer='below traces',
    row=2, col=1
)
fig.update_yaxes(
    gridcolor='rgba(128, 128, 128, 0.1)',
    tickfont=dict(family='Inter, sans-serif', size=10),
    zeroline=False,
    row=3, col=1
)

# Update x-axes with enhanced styling
fig.update_xaxes(
    gridcolor='rgba(128, 128, 128, 0.1)',
    zeroline=False,
    showspikes=True,  # Add spike lines for better navigation
    spikecolor='rgba(255, 255, 255, 0.3)',
    spikethickness=1,
    spikedash='dot',
    spikemode='across',
    tickfont=dict(family='Inter, sans-serif', size=10),
    row=1, col=1
)
fig.update_xaxes(
    gridcolor='rgba(128, 128, 128, 0.1)',
    zeroline=False,
    tickfont=dict(family='Inter, sans-serif', size=10),
    row=2, col=1
)
fig.update_xaxes(
    gridcolor='rgba(128, 128, 128, 0.1)',
    zeroline=False,
    tickfont=dict(family='Inter, sans-serif', size=10),
    row=3, col=1
)

# Add colored zones for RSI indicator
fig.add_shape(
    type="rect", 
    fillcolor="rgba(239, 83, 80, 0.1)", 
    line=dict(width=0), 
    x0=candles.index[0], 
    x1=candles.index[-1], 
    y0=70, 
    y1=100, 
    row=2, col=1
)
fig.add_shape(
    type="rect", 
    fillcolor="rgba(38, 166, 154, 0.1)", 
    line=dict(width=0), 
    x0=candles.index[0], 
    x1=candles.index[-1], 
    y0=0, 
    y1=30, 
    row=2, col=1
)

# Display chart
st.plotly_chart(fig, use_container_width=True)

# Close the chart container div
st.markdown("</div>", unsafe_allow_html=True)

# Trade information section - split into two columns
col1, col2 = st.columns(2)

# Trade Snapshot
with col1:
    st.markdown("""
    <div style='background: linear-gradient(90deg, #1a1f29 0%, #13172290 100%); padding: 15px; 
         border-radius: 10px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); border-left: 3px solid #4da6ff;'>
        <h3 style='display: flex; align-items: center;'>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#4da6ff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
            </svg>
            <span style='margin-left: 10px;'>Trade Snapshot</span>
        </h3>
    </div>
    """, unsafe_allow_html=True)
    
    trade = st.session_state.last_trade
    
    status_color = "#26a69a" if trade['status'] == 'Trade Executed' else "#f0ad4e"
    status_glow = "0 0 10px rgba(38, 166, 154, 0.5)" if trade['status'] == 'Trade Executed' else "0 0 10px rgba(240, 173, 78, 0.5)"
    
    # Create styled trade card
    st.markdown(f"""
    <div style='background-color: #1e2430; border-radius: 8px; padding: 15px; margin-top: 10px; 
         box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); border: 1px solid #2c3242;'>
        <div style='display: flex; align-items: center; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #2c3242;'>
            <div style='background-color: {status_color}; width: 12px; height: 12px; border-radius: 50%; margin-right: 10px; box-shadow: {status_glow};'></div>
            <span style='font-weight: bold; font-size: 1.1em;'>{trade['status']}</span>
        </div>
    """, unsafe_allow_html=True)
    
    # Create two main columns for the trade details with styled appearance
    col1a, col1b = st.columns(2)
    
    with col1a:
        # Direction with icon
        direction_icon = "↗️" if trade['direction'] == 'BUY' else "↘️"
        direction_color = "#26a69a" if trade['direction'] == 'BUY' else "#ef5350"
        
        st.markdown(f"""
        <div style='margin-bottom: 15px;'>
            <span style='color: #9e9e9e; font-size: 0.9em;'>Pair</span><br>
            <span style='font-weight: bold; font-size: 1.3em; color: {direction_color};'>
                {direction_icon} {trade['direction']}
            </span>
        </div>
        
        <div style='margin-bottom: 15px;'>
            <span style='color: #9e9e9e; font-size: 0.9em;'>Lot size</span><br>
            <span style='font-weight: 500; font-size: 1.1em;'>{trade['lot_size']}</span>
        </div>
        """, unsafe_allow_html=True)
    
    with col1b:
        st.markdown(f"""
        <div style='margin-bottom: 15px;'>
            <span style='color: #9e9e9e; font-size: 0.9em;'>Firm</span><br>
            <span style='font-weight: 500; font-size: 1.1em;'>{trade['firm']}</span>
        </div>
        
        <div style='margin-bottom: 15px;'>
            <span style='color: #9e9e9e; font-size: 0.9em;'>Entry</span><br>
            <span style='font-weight: 600; font-size: 1.1em; color: #4da6ff;'>{trade['entry']}</span>
        </div>
        
        <div style='margin-bottom: 15px;'>
            <span style='color: #9e9e9e; font-size: 0.9em;'>Lat size</span><br>
            <span style='font-weight: 500; font-size: 1.1em;'>{trade['lat_size']}</span>
        </div>
        """, unsafe_allow_html=True)
    
    # Close the trade card div
    st.markdown("</div>", unsafe_allow_html=True)

# Trade Log
with col2:
    st.markdown("""
    <div style='background: linear-gradient(90deg, #1a1f29 0%, #13172290 100%); padding: 15px; 
         border-radius: 10px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2); border-left: 3px solid #4da6ff;'>
        <h3 style='display: flex; align-items: center;'>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#4da6ff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"/>
                <path d="M12 11l5 5m-5-5l-5 5"/>
                <path d="M12 6v10"/>
            </svg>
            <span style='margin-left: 10px;'>Trade Log</span>
        </h3>
    </div>
    """, unsafe_allow_html=True)
    
    # Create styled trade log container
    st.markdown("""
    <div style='background-color: #1e2430; border-radius: 8px; padding: 15px; margin-top: 10px; 
         box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); border: 1px solid #2c3242; max-height: 300px; overflow-y: auto;'>
    """, unsafe_allow_html=True)
    
    # Display trade logs with colorful indicators based on message content
    for log in st.session_state.trade_log[:5]:  # Show only the 5 most recent logs
        log_color = "#26a69a" if "BUY" in log['message'] else "#ef5350" if "SELL" in log['message'] else "#4da6ff"
        log_bg = "rgba(38, 166, 154, 0.1)" if "BUY" in log['message'] else "rgba(239, 83, 80, 0.1)" if "SELL" in log['message'] else "transparent"
        log_border = f"1px solid {log_color}" if "executed" in log['message'].lower() else "none"
        log_icon = "↗️" if "BUY" in log['message'] else "↘️" if "SELL" in log['message'] else "🔍" if "Scan" in log['message'] else "📊"
        
        st.markdown(f"""
        <div style='margin-bottom: 8px; padding: 8px; border-radius: 6px; background-color: {log_bg}; border-left: 3px solid {log_color}; border: {log_border};'>
            <div style='display: flex; align-items: center;'>
                <span style='color: #9e9e9e; font-size: 0.9em; min-width: 50px;'>{log['time']}</span>
                <span style='font-weight: 500;'>{log_icon} {log['message']}</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    # Close the log container
    st.markdown("</div>", unsafe_allow_html=True)

# Auto-refresh the page every 5 seconds
st.markdown("""
<script>
    setTimeout(function(){
        window.location.reload();
    }, 5000);
</script>
""", unsafe_allow_html=True)
