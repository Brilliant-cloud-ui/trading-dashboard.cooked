import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

def generate_candle_data(pair, timeframe, n_candles=100):
    """
    Generate sample candle data for demo purposes
    
    Parameters:
    -----------
    pair : str
        Currency pair
    timeframe : str
        Time frame (1H, 4H, 1D)
    n_candles : int
        Number of candles to generate
    
    Returns:
    --------
    pd.DataFrame
        DataFrame with OHLC data
    """
    # Set random seed based on pair for consistency
    pair_seed = sum(ord(c) for c in pair)
    np.random.seed(pair_seed)
    
    # Base price values for different pairs
    pair_prices = {
        'EUR/USD': 1.08,
        'GBP/USD': 1.26,
        'USD/JPY': 155.0,
        'AUD/USD': 0.65,
        'USD/CAD': 1.37,
        'NZD/USD': 0.59
    }
    
    base_price = pair_prices.get(pair, 1.0)
    volatility = base_price * 0.0025  # 0.25% volatility
    
    # Time intervals based on timeframe
    if timeframe == '1min':
        time_delta = timedelta(minutes=1)
    elif timeframe == '5min':
        time_delta = timedelta(minutes=5)
    elif timeframe == '15min':
        time_delta = timedelta(minutes=15)
    elif timeframe == '30min':
        time_delta = timedelta(minutes=30)
    elif timeframe == '1H':
        time_delta = timedelta(hours=1)
    elif timeframe == '4H':
        time_delta = timedelta(hours=4)
    elif timeframe == '1D':
        time_delta = timedelta(days=1)
    elif timeframe == '1M':
        time_delta = timedelta(days=30)  # Approximate month
    elif timeframe == '1Y':
        time_delta = timedelta(days=365)  # Approximate year
    else:
        time_delta = timedelta(hours=1)  # Default to 1H
    
    # Generate dates
    end_date = datetime.now()
    dates = [end_date - i * time_delta for i in range(n_candles)]
    dates.reverse()
    
    # Generate price data with some trend and randomness
    close_prices = []
    price = base_price
    
    # Create a slight trend
    trend = np.linspace(-volatility*5, volatility*5, n_candles)
    
    for i in range(n_candles):
        # Add some randomness and trend
        rnd = np.random.normal(0, volatility)
        price = price + rnd + trend[i] / n_candles
        # Ensure price doesn't go negative or too far from base
        price = max(price, base_price * 0.8)
        price = min(price, base_price * 1.2)
        close_prices.append(price)
    
    # Generate OHLC data
    data = []
    for i in range(n_candles):
        close = close_prices[i]
        # Generate open, high, low based on close
        open_price = close_prices[i-1] if i > 0 else close * (1 + np.random.normal(0, volatility/base_price))
        high = max(open_price, close) * (1 + abs(np.random.normal(0, volatility/base_price/2)))
        low = min(open_price, close) * (1 - abs(np.random.normal(0, volatility/base_price/2)))
        
        data.append([open_price, high, low, close])
    
    # Create DataFrame
    df = pd.DataFrame(data, columns=['open', 'high', 'low', 'close'], index=dates)
    return df

def calculate_rsi(prices, period=14):
    """
    Calculate Relative Strength Index (RSI)
    
    Parameters:
    -----------
    prices : array-like
        Array of price data
    period : int
        RSI period
    
    Returns:
    --------
    array
        RSI values
    """
    # Calculate price changes
    deltas = np.diff(prices)
    seed = deltas[:period+1]
    up = seed[seed >= 0].sum()/period
    down = -seed[seed < 0].sum()/period
    rs = up/down if down != 0 else 0
    rsi = np.zeros_like(prices)
    rsi[:period] = 100. - 100./(1. + rs)
    
    # Calculate RSI
    for i in range(period, len(prices)):
        delta = deltas[i-1]
        if delta > 0:
            upval = delta
            downval = 0.
        else:
            upval = 0.
            downval = -delta
            
        up = (up * (period - 1) + upval) / period
        down = (down * (period - 1) + downval) / period
        
        rs = up/down if down != 0 else 0
        rsi[i] = 100. - 100./(1. + rs)
        
    return rsi

def calculate_atr(high, low, close, period=14):
    """
    Calculate Average True Range (ATR)
    
    Parameters:
    -----------
    high : array-like
        Array of high prices
    low : array-like
        Array of low prices
    close : array-like
        Array of close prices
    period : int
        ATR period
    
    Returns:
    --------
    array
        ATR values
    """
    # Calculate true range
    tr1 = high - low
    tr2 = np.abs(high - np.roll(close, 1))
    tr3 = np.abs(low - np.roll(close, 1))
    tr = np.maximum(np.maximum(tr1, tr2), tr3)
    tr[0] = tr1[0]  # First value is simply the first high-low
    
    # Calculate ATR
    atr = np.zeros_like(high)
    atr[0] = tr[0]
    
    for i in range(1, len(atr)):
        atr[i] = ((period - 1) * atr[i-1] + tr[i]) / period
        
    return atr
