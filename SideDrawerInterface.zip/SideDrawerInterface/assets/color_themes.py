# Color theme definitions for the dashboard
themes = {
    "Turquoise Gold": {
        "primary": "#00c7b7",  # Turquoise
        "secondary": "#f5b942",  # Gold/orange
        "background": "#121721",  # Very dark blue
        "card_bg": "#1a2433",  # Dark blue-gray
    },
    "Electric Blue Coral": {
        "primary": "#2271FF",  # Electric blue
        "secondary": "#FF5E5B",  # Coral
        "background": "#0F1119",  # Very dark blue-black
        "card_bg": "#1A1C27",  # Dark slate
    },
    "Purple Gold": {
        "primary": "#9966CC",  # Deep purple
        "secondary": "#FFD700",  # Bright gold
        "background": "#0E0E12",  # Almost black
        "card_bg": "#1E1E24",  # Dark charcoal
    },
    "Emerald Magenta": {
        "primary": "#50C878",  # Emerald green
        "secondary": "#FF00FF",  # Magenta
        "background": "#111111",  # Pure black
        "card_bg": "#1A1A1A",  # Dark gray
    },
    "Red Silver": {
        "primary": "#FF3131",  # Bright red
        "secondary": "#D3D3D3",  # Light gray/silver
        "background": "#121212",  # Very dark gray
        "card_bg": "#1D1D1D",  # Dark gray
    },
    "Slate Mint": {
        "primary": "#708090",  # Slate gray
        "secondary": "#98FF98",  # Mint green
        "background": "#0D0D0D",  # Almost black
        "card_bg": "#181818",  # Dark gray
    },
    "Navy Orange": {
        "primary": "#000080",  # Navy blue
        "secondary": "#FFA500",  # Orange
        "background": "#101010",  # Almost black
        "card_bg": "#1B1B1B",  # Dark gray
    }
}

def get_theme_css(theme_name):
    """Generate CSS for the selected theme"""
    if theme_name not in themes:
        theme_name = "Turquoise Gold"  # Default theme
    
    theme = themes[theme_name]
    
    return f"""
    /* CSS Variables for {theme_name} theme */
    :root {{
        --primary-color: {theme["primary"]};
        --secondary-color: {theme["secondary"]};
        --background-color: {theme["background"]};
        --card-bg-color: {theme["card_bg"]};
        --text-color: #ffffff;
        --text-secondary: #aaaaaa;
        --danger-color: #ff4444;
        --success-color: #00C851;
    }}
    
    /* Apply theme colors to elements */
    body {{
        background-color: var(--background-color);
    }}
    
    .positive-metric {{
        color: var(--primary-color);
    }}
    
    .negative-metric {{
        color: var(--secondary-color);
    }}
    
    .metric-icon {{
        color: var(--primary-color);
    }}
    
    /* Buttons with primary color */
    .stButton > button {{
        background-image: linear-gradient(to right, var(--primary-color), {_darken_hex(theme["primary"], 0.1)});
    }}
    
    /* Buy button with primary color */
    button[key="tf_Buy"] {{
        background-image: linear-gradient(to right, var(--primary-color), {_darken_hex(theme["primary"], 0.1)});
    }}
    
    /* Sell button with secondary color */
    button[key="tf_Sell"] {{
        background-image: linear-gradient(to right, var(--secondary-color), {_darken_hex(theme["secondary"], 0.1)});
    }}
    
    /* Timeline slider handle */
    div.stSlider > div > div > div > div {{
        background-color: var(--primary-color) !important;
        box-shadow: 0 0 5px var(--primary-color);
    }}
    
    /* Scrollbar styling */
    ::-webkit-scrollbar-thumb:hover {{
        background: var(--primary-color);
    }}
    """

def _darken_hex(hex_color, factor=0.2):
    """Darken a hex color by the given factor"""
    # Remove the # if present
    hex_color = hex_color.lstrip('#')
    
    # Convert to RGB
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    
    # Darken each component
    r = max(0, int(r * (1 - factor)))
    g = max(0, int(g * (1 - factor)))
    b = max(0, int(b * (1 - factor)))
    
    # Convert back to hex
    return f"#{r:02x}{g:02x}{b:02x}"